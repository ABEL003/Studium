﻿using System;

namespace Ampel
{
    class Program
    {
        static void Main(string[] args)
        {
            var eineAmpel = new Ampel();

            eineAmpel.SetAmpelFarbe(Ampelfarbe.Rot);
            eineAmpel.SetAmpelFarbe(Ampelfarbe.Gelb);
            eineAmpel.SetAmpelFarbe(Ampelfarbe.Gruen);
            eineAmpel.SetAmpelFarbe(Ampelfarbe.Rot);

            Console.WriteLine($"Die Anzahl der Rotphasen ist: {eineAmpel.GetAnzahlRotPhasen()}");
        }
    }
}