﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ampel
{
    public enum Ampelfarbe
    {
        Rot,
        Gelb,
        Gruen
    }

    public class Ampel
    {
        private Ampelfarbe ampelfarbe;
        private int anzahlRotPhasen;

        public Ampelfarbe GetAmpelfarbe()
        {
            return ampelfarbe;
        }

        public void SetAmpelFarbe(Ampelfarbe ampelfarbe)
        {
            this.ampelfarbe = ampelfarbe;

            if (ampelfarbe == Ampelfarbe.Rot)
            {
                anzahlRotPhasen++;
            }
        }

        public int GetAnzahlRotPhasen()
        {
            return anzahlRotPhasen;
        }
    }
}