﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ampel
{
    public enum Ampelfarbe
    {
        Rot,
        Gelb,
        Gruen
    }

    public class Ampel
    {
        public int AnzahlRotphasen { get; private set; }

        private Ampelfarbe ampelfarbe;

        public Ampelfarbe Ampelfarbe
        {
            get
            {
                return ampelfarbe;
            }
            set
            {
                ampelfarbe = value;

                if (ampelfarbe == Ampelfarbe.Rot)
                {
                    AnzahlRotphasen++;
                }
            }
        }
    }
}