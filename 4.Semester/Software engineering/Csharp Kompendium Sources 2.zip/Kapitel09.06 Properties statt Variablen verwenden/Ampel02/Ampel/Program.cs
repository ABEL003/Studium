﻿using System;

namespace Ampel
{
    class Program
    {
        public Ampelfarbe Ampelfarbe { get; private set; }

        static void Main(string[] args)
        {
            var eineAmpel = new Ampel();
            eineAmpel.Ampelfarbe = Ampelfarbe.Rot;
            eineAmpel.Ampelfarbe = Ampelfarbe.Gelb;
            eineAmpel.Ampelfarbe = Ampelfarbe.Gruen;
            eineAmpel.Ampelfarbe = Ampelfarbe.Rot;

            Console.WriteLine($"Die Anzahl der Rotphasen ist: {eineAmpel.AnzahlRotphasen}");
        }
    }
}
