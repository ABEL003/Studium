﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonvertierenMitLinq
{
    public class Person : Adresse
    {
        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public override string ToString()
        {
            return $"{Vorname} {Nachname} {Ort} {Strasse}";
        }

        public static List<Person> AllePersonen
        {
            get
            {
                return new List<Person>
                {
                    new Person
                    {
                        Vorname = "Max",
                        Nachname = "Musterperson",
                        Ort = "Musterhausen",
                        Strasse = "Musterstr. 1"
                    },
                    new Person
                    {
                        Vorname = "Marta",
                        Nachname = "Musterperson",
                        Ort = "Musterstadt",
                        Strasse = "Musterweg 7"
                    },
                    new Person
                    {
                        Vorname = "Tim",
                        Nachname = "Testperson",
                        Ort = "Testhausen",
                        Strasse = "Testgasse 5"
                    },
                    new Person
                    {
                        Vorname = "Tina",
                        Nachname = "Testperson",
                        Ort = "Testdorf",
                        Strasse = "Testallee 8"
                    },
                };
            }
        }
    }
}