﻿using System;
using System.Linq;

namespace KonvertierenMitLinq
{
    class Program
    {
        static void Main(string[] args)
        {
            var sortiertePersonen = Person.AllePersonen.OrderBy(p => p.Nachname).ThenBy(p => p.Vorname);

            foreach (var person in sortiertePersonen)
            {
                Console.WriteLine(person);
            }
        }
    }
}