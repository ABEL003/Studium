﻿using System;
using System.Linq;

namespace VerschachtelteLinqAusdruecke
{
    class Program
    {
        static void Main(string[] args)
        {
            var fiatBesitzer = Person.AllePersonen.Where(p => p.Autos.Any(a => a.Marke == "Fiat"));

            foreach (var person in fiatBesitzer)
            {
                Console.WriteLine(person);
            }
        }
    }
}