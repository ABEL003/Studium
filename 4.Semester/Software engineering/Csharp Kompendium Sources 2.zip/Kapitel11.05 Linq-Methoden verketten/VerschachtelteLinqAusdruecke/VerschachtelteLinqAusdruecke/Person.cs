﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VerschachtelteLinqAusdruecke
{
    public class Person
    {
        public string Nachname { get; set; }
        public string Vorname { get; set; }

        public IEnumerable<Auto> Autos { get; set; }

        public override string ToString()
        {
            var autos = "";
            foreach (var auto in Autos)
            {
                autos += $"{auto} ";
            }

            return $"{Vorname} {Nachname} {autos}";
        }

        public static IEnumerable<Person> AllePersonen
        {
            get
            {
                return new List<Person>
                {
                    new Person
                    {
                        Nachname = "Müller",
                        Vorname = "Hans",
                        Autos = new List<Auto>
                        {
                            new Auto
                            {
                                Marke = "BMW",
                                Modell = "320i"
                            },
                            new Auto
                            {
                                Marke = "Fiat",
                                Modell = "Panda"
                            }
                        }
                    },
                    new Person
                    {
                        Nachname = "Meier",
                        Vorname = "Julia",
                        Autos = new List<Auto>
                        {
                            new Auto
                            {
                                Marke = "Audi",
                                Modell =
                            "A4"
                            },
                            new Auto
                            {
                            Marke = "Fiat",
                            Modell =
                            "Punto"
                            }
                        }
                    },
                    new Person
                    {
                        Nachname = "Huber",
                        Vorname = "Gerd",

                        Autos = new List<Auto>
                        {
                            new Auto
                            {
                                Marke = "Mercedes",
                                Modell = "E240",
                            },
                            new Auto
                            {
                                Marke = "Ford",
                                Modell = "Fiesta"
                            }
                        }
                    },
                    new Person
                    {
                        Nachname = "Mahler",
                        Vorname = "Sonja",
                        Autos = new List<Auto>
                        {
                            new Auto
                            {
                                Marke = "VW",
                                Modell =
                                "Phaeton"
                            },
                            new Auto
                            {
                                Marke = "Ford",
                                Modell =
                                "Focus"
                            }
                        }
                    }
                };
            }
        }
    }
}