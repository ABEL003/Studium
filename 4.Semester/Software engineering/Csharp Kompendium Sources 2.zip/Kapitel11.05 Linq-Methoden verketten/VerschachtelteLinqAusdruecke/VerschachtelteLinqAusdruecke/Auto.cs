﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VerschachtelteLinqAusdruecke
{
    public class Auto
    {
        public string Marke { get; set; }
        public string Modell { get; set; }

        public override string ToString()
        {
            return $"{Marke} {Modell}";
        }
    }
}