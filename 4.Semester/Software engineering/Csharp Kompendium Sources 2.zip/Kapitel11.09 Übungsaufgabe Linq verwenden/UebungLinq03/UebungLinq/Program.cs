﻿using System;
using System.Linq;

namespace UebungLinq
{
    class Program
    {
        static void Main(string[] args)
        {
            var klassenMitSchuelerMitM = Schulklasse.AlleKlassen.Where(sk => sk.Schueler.Any(s => s.Nachname.StartsWith("M")));

            foreach (var klasse in klassenMitSchuelerMitM)
 {
                Console.WriteLine(klasse);
            }
        }
    }
}