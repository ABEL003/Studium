﻿using System;
using System.Linq;

namespace UebungLinq
{
    class Program
    {
        static void Main(string[] args)
        {
            var klasseOhneSchueler = Schulklasse.AlleKlassen
            .Where(sk => sk.Schueler.Count() == 0)
            .FirstOrDefault();

            Console.WriteLine(klasseOhneSchueler);
        }
    }
}