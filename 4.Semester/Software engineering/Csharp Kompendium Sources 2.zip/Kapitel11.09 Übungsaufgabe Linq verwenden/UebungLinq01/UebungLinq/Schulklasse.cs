﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UebungLinq
{
    public class Schulklasse
    {
        public string Bezeichnung { get; set; }

        public List<Schueler> Schueler { get; set; }

        public override string ToString()
        {
            return Bezeichnung;
        }

        public static List<Schulklasse> AlleKlassen
        {
            get
            {
                return new List<Schulklasse>
                {
                    new Schulklasse
                    {
                        Bezeichnung = "1a",
                        Schueler = new List<Schueler>
                        {
                            new Schueler
                            {
                                Vorname = "Max",
                                Nachname = "Müller"
                            },
                            new Schueler
                            {
                                Vorname = "Anna",
                                Nachname = "Meier"
                            },
                        }
                    },
                    new Schulklasse
                    {
                        Bezeichnung = "2b",
                        Schueler = new List<Schueler>
                        {
                            new Schueler
                            {
                                Vorname = "Fritz",
                                Nachname = "Huber"
                            },
                            new Schueler
                            {
                                Vorname = "Anna",
                                Nachname = "Neumann"
                            },
                        }
                    },
                    new Schulklasse
                    {
                        Bezeichnung = "3c",
                        Schueler = new List<Schueler>
                        {
                            new Schueler
                            {
                                Vorname = "Gerda",
                                Nachname = "Müller"
                            },
                            new Schueler
                            {
                                Vorname = "Martin",
                                Nachname = "Mahler"
                            },
                        }
                    },
                    new Schulklasse
                    {
                        Bezeichnung = "4d",
                        Schueler = new List<Schueler>()
                    }
                };
            }
        }
    }
}