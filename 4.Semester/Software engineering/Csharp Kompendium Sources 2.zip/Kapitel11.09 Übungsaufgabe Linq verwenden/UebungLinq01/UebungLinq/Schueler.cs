﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UebungLinq
{
    public class Schueler
    {
        public string Vorname { get; set; }

        public string Nachname { get; set; }

        public override string ToString()
        {
            return $"{Vorname} {Nachname}";
        }
    }
}