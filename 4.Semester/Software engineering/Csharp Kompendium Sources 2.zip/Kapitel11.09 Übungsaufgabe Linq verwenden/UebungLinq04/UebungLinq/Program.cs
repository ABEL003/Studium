﻿using System;
using System.Linq;

namespace UebungLinq
{
    class Program
    {
        static void Main(string[] args)
        {
            var vornamenAllerSchueler = Schulklasse.AlleKlassen
                .SelectMany(sk => sk.Schueler)
                .OrderBy(s => s.Vorname)
                .Select(s => s.Vorname);

            foreach (var vorname in vornamenAllerSchueler)
            {
                Console.WriteLine(vorname);
            }
        }
    }
}
