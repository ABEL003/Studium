﻿using System;

namespace GarbageCollector
{
    class Program
    {
        static void Main(string[] args)
        {
            var grosseKlasse = new GrosseKlasse();
            grosseKlasse.vieleZeilen = null;
            Console.ReadLine();
            GC.Collect();
            Console.ReadLine();
        }
    }
}
