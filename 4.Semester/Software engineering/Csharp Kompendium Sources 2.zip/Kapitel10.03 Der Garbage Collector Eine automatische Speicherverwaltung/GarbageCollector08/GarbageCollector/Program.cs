﻿using System;
using System.Collections.Generic;

namespace GarbageCollector
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                var liste = new List<GrosseKlasse>();

                while (true)
                {
                    var grosseKlasse = new GrosseKlasse();
                    liste.Add(grosseKlasse);
                }
            }
        }
    }
}
