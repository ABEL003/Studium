﻿using System;

namespace GarbageCollector
{
    class Program
    {
        static void Main(string[] args)
        {
            var grosseKlasse = new GrosseKlasse();
            Console.ReadLine();
            GC.Collect();
            Console.ReadLine();
        }
    }
}
