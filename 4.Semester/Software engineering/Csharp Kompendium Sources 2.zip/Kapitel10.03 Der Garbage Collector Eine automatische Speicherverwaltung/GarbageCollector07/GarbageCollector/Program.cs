﻿using System;

namespace GarbageCollector
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                var grosseKlasse = new GrosseKlasse();
            }
        }
    }
}
