﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GarbageCollector
{
    public class GrosseKlasse
    {
        string zeile = "Das ist eine Text Zeile.";
        public List<string> vieleZeilen { get; set; } = new List<string>();

        public GrosseKlasse()
        {
            for (var i = 0; i < 1000000; i++)
            {
                vieleZeilen.Add(zeile);
            }
        }
    }
}
