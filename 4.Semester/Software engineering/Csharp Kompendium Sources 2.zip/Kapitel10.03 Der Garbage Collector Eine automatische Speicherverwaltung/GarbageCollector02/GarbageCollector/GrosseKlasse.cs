﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GarbageCollector
{
    public class GrosseKlasse
    {
        public GrosseKlasse()
        {
            var zeile = "Das ist eine Text Zeile.";
            var vieleZeilen = new List<string>();

            for (var i = 0; i < 1000000; i++)
            {
                vieleZeilen.Add(zeile);
            }

        }
    }
}
