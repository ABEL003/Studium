﻿using System;

namespace TelefonVerzeichnisObjektorientiert
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
