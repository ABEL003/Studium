﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TelefonVerzeichnisObjektorientiert
{
    public class Verzeichnis
    {
        private Dictionary<string, VerzeichnisEintrag> verzeichnis = new Dictionary<string, VerzeichnisEintrag>();

        public Verzeichnis()
        {
            NeuerEintrag("Robert", "Schiefele", "08912356489", "01715589665", "robert.schiefele@email.de");
            NeuerEintrag("Katia", "Japa", "0897589445", "017259894", "katia.japa@email.de");
            NeuerEintrag("Theo", "Tester", "089885595445", "017365894", "theo.tester@email.de");
        }

        public void NeuerEintrag(string vorname, string nachname, string festnetz, string mobilfunk, string email)
        {
            verzeichnis.Add($"{vorname}:{nachname}", new VerzeichnisEintrag(vorname, nachname, festnetz, mobilfunk, email));
        }

        public void ZeigeAlleEintraege()
        {
            foreach (var eintrag in verzeichnis.Values)
            {
                eintrag.ZeigeEintrag();
            }
        }

        public void ZeigeEintrag(string schluessel)
        {
            if (verzeichnis.ContainsKey(schluessel))
            {
                verzeichnis[schluessel].ZeigeEintrag();
            }
            else
            {
                Console.WriteLine($"Eintrag: {schluessel} nicht gefunden.");
            }
        }

        public void ZeigeEintraegeFuerNachname(string nachname)
        {
            var gefunden = false;

            foreach (var element in verzeichnis)
            {
                if (element.Value.Nachname == nachname)
                {
                    element.Value.ZeigeEintrag();
                    gefunden = true;
                }
            }

            if (!gefunden)
            {
                Console.WriteLine($"Keinen Eintrag für {nachname} gefunden");
            }
        }

        public void ZeigeEintraegeFuerVorname(string vorname)
        {
            var gefunden = false;

            foreach (var element in verzeichnis)
            {
                if (element.Value.Vorname == vorname)
                {
                    element.Value.ZeigeEintrag();
                    gefunden = true;
                }
            }

            if (!gefunden)
            {
                Console.WriteLine($"Keinen Eintrag für {vorname} gefunden");
            }
        }
    }
}
