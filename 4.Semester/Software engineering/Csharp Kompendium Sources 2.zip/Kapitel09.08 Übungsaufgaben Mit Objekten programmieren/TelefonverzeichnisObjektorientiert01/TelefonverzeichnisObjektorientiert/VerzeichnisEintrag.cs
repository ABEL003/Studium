﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TelefonVerzeichnisObjektorientiert
{
    public class VerzeichnisEintrag
    {
        public string Vorname { get; set; }
        public string Nachname { get; set; }
        public string Festnetz { get; set; }
        public string Mobilfunk { get; set; }
        public string Email { get; set; }

        public VerzeichnisEintrag(string vorname, string
        nachname, string festnetz, string mobilfunk, string
        email)
        {
            Vorname = vorname;
            Nachname = nachname;
            Festnetz = festnetz;
            Mobilfunk = mobilfunk;
            Email = email;
        }

        public void ZeigeEintrag()
        {
            Console.WriteLine($"{Vorname} {Nachname}; Festnetz: { Festnetz}; Mobilfunk: { Mobilfunk}; Email: { Email}");
        }
    }
}

