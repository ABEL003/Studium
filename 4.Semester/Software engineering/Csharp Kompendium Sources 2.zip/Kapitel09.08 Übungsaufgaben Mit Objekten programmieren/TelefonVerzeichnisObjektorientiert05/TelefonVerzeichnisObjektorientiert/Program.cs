﻿using System;

namespace TelefonVerzeichnisObjektorientiert
{
    class Program
    {
        static void Main(string[] args)
        {
            new VerzeichnisApp().Start();
        }
    }
}