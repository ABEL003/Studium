﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TelefonVerzeichnisObjektorientiert
{
    public class VerzeichnisApp
    {
        private Verzeichnis verzeichnis;

        public VerzeichnisApp()
        {
            verzeichnis = new Verzeichnis();
        }

        private void ZeigeMenu()
        {
            Console.Clear();
            Console.WriteLine("1. Alle Einträge anzeigen.");
            Console.WriteLine("2. Einen bestimmten Eintrag anzeigen");
            Console.WriteLine("3. Einträge suchen nach Vornamen.");
            Console.WriteLine("4. Einträge suchen nach Nachnamen.");
            Console.WriteLine("5. Eintrag hinzufügen.");
            Console.WriteLine("6. Eintrag ändern.");
            Console.WriteLine("7. Eintrag löschen");
            Console.WriteLine("8. Programm beenden.");
            Console.
          WriteLine("-------------------------------------");
            Console.WriteLine("Wählen Sie einen Menüpunkt (1-8)");
        }

        private int LeseMenuPunkt()
        {
            int menupunkt;
            do
            {
                if (int.TryParse(Console.ReadLine(), out
                menupunkt))
                {
                    if (menupunkt >= 1 && menupunkt <= 8)
                    {
                        break;
                    }
                }
                Console.WriteLine("Wählen Sie einen Menüpunkt (1-8)");
            }
            while (1 == 1);

            return menupunkt;
        }

        public void Start()
        {
            var ende = false;
            while (!ende)
            {
                ZeigeMenu();

                switch (LeseMenuPunkt())
                {
                    case 8:
                        ende = true;
                        break;
                }
            }
        }
    }
}
