﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TelefonVerzeichnisObjektorientiert
{
    public class VerzeichnisApp
    {
        private Verzeichnis verzeichnis;

        public VerzeichnisApp()
        {
            verzeichnis = new Verzeichnis();
        }

        private void ZeigeMenu()
        {
            Console.Clear();
            Console.WriteLine("1. Alle Einträge anzeigen.");
            Console.WriteLine("2. Einen bestimmten Eintrag anzeigen");
            Console.WriteLine("3. Einträge suchen nach Vornamen.");
            Console.WriteLine("4. Einträge suchen nach Nachnamen.");
            Console.WriteLine("5. Eintrag hinzufügen.");
            Console.WriteLine("6. Eintrag ändern.");
            Console.WriteLine("7. Eintrag löschen");
            Console.WriteLine("8. Programm beenden.");
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("Wählen Sie einen Menüpunkt (1-8)");
        }

        private int LeseMenuPunkt()
        {
            int menupunkt;
            do
            {
                if (int.TryParse(Console.ReadLine(), out
                menupunkt))
                {
                    if (menupunkt >= 1 && menupunkt <= 8)
                    {
                        break;
                    }
                }
                Console.WriteLine("Wählen Sie einen Menüpunkt (1-8)");
            }
            while (1 == 1);

            return menupunkt;
        }

        private void ZeigeAlleEintraege()
        {
            Console.Clear();
            verzeichnis.ZeigeAlleEintraege();
            Zurueck();
        }

        private void ZeigeEintrag()
        {
            Console.Clear();
            Console.WriteLine("Geben Sie einen Schlüssel (Vorname:Nachname) ein.");
            verzeichnis.ZeigeEintrag(Console.ReadLine());
            Zurueck();
        }

        private void SucheEintragNachVornamen()
        {
            Console.Clear();
            Console.WriteLine("Geben Sie einen Vornamen ein.");
            verzeichnis.ZeigeEintraegeFuerVorname(Console.ReadLine());
            Zurueck();
        }

        private void SucheEintragNachNachnamen()
        {
            Console.Clear();
            Console.WriteLine("Geben Sie einen Nachnamen ein.");
            verzeichnis.ZeigeEintraegeFuerNachname(Console.ReadLine());
            Zurueck();
        }

        private void Zurueck()
        {
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("Drücken Sie die Enter-Taste, um zum Menü zu gelangen.");
            Console.ReadLine();
        }

        public void Start()
        {
            var ende = false;
            while (!ende)
            {
                ZeigeMenu();

                switch (LeseMenuPunkt())
                {
                    case 1:
                        ZeigeAlleEintraege();
                        break;
                    case 2:
                        ZeigeEintrag();
                        break;
                    case 3:
                        SucheEintragNachVornamen();
                        break;
                    case 4:
                        SucheEintragNachNachnamen();
                        break;
                    case 8:
                        ende = true;
                        break;
                }
            }
        }
    }
}