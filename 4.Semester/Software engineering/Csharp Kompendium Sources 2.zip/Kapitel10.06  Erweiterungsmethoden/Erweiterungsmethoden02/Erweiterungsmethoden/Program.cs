﻿using System;

namespace Erweiterungsmethoden
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = null;
            Console.WriteLine(text.AlsBereinigt());
        }
    }
}
