﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Erweiterungsmethoden
{
    public static class StringErweiterungen
    {
        public static string AlsBereinigt(this string einString)
        {
            if (einString == null)
            {
                return string.Empty;
            }
            else
            {
                return einString.Trim();
            }
        }
    }
}