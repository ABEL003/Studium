﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenerischeProperties
{
    public class MeineKlasse<T, K>
    {
        public T Parameter1 { get; set; }
        public K Parameter2 { get; set; }
        public MeineKlasse(T parameter1, K parameter2)
        {
            Parameter1 = parameter1;
            Parameter2 = parameter2;
        }
    }
}