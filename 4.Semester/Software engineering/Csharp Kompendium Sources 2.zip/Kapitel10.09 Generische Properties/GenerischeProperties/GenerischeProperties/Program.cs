﻿using System;

namespace GenerischeProperties
{
    class Program
    {
        static void Main(string[] args)
        {
            var meineKlasse1 = new MeineKlasse<string, DateTime>("Hallo", DateTime.Now);
            var meineKlasse2 = new MeineKlasse<int, bool>(42, true);

            Console.WriteLine($"{meineKlasse1.Parameter1} {meineKlasse1.Parameter2}");
            Console.WriteLine($"{meineKlasse2.Parameter1} { meineKlasse2.Parameter2}");
        }
    }
}