﻿using System;

namespace Vererbung
{
    class Program
    {
        static void Main(string[] args)
        {
            var student = new Student();
            student.Universitaet = "Freie Universität Berlin";
            student.Vorname = "Max";
            student.Nachname = "Mustermann";
            student.Strasse = "Musterstrasse 6";
            student.Plz = "12345";
            student.Ort = "Musterhausen";
            student.ZeigeStudent();
        }
    }
}
