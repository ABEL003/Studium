﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vererbung
{
    public class Person : Adresse
    {
        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public void ZeigePerson()
        {
            Console.WriteLine($"{Vorname} {Nachname}");
            ZeigeAdresse();
        }
    }
}