﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vererbung
{
    public class Student : Person
    {
        public string Universitaet { get; set; }

        public void ZeigeStudent()
        {
            Console.WriteLine(Universitaet);
            ZeigePerson();
        }
    }
}
