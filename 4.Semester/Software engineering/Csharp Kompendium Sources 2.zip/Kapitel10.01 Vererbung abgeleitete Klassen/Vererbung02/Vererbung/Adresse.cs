﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vererbung
{
    public class Adresse
    {
        public Adresse(string strasse, string ort, string plz)
        {
            Strasse = strasse;
            Ort = ort;
            Plz = plz;
        }

        public string Strasse { get; set; }
        public string Ort { get; set; }
        public string Plz { get; set; }

        public void ZeigeAdresse()
        {
            Console.WriteLine(Strasse);
            Console.WriteLine($"{Plz} {Ort}");
        }
    }
}