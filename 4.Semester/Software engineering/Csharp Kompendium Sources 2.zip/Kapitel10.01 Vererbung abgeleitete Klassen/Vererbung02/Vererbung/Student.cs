﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vererbung
{
    public class Student : Person
    {
        public Student(string universitaet, string vorname, string nachname, string strasse, string ort, string plz) :
        base(vorname, nachname, strasse, ort, plz)
        {
            Universitaet = universitaet;
        }

        public string Universitaet { get; set; }

        public void ZeigeStudent()
        {
            Console.WriteLine(Universitaet);
            ZeigePerson();
        }
    }
}
