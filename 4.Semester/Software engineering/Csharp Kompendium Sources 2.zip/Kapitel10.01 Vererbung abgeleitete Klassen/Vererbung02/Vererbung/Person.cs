﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vererbung
{
    public class Person : Adresse
    {
        public Person(string vorname, string nachname, string strasse, string ort, string plz) : 
        base(strasse, ort, plz)
        {
            Vorname = vorname;
            Nachname = nachname;
        }

        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public void ZeigePerson()
        {
            Console.WriteLine($"{Vorname} {Nachname}");
            ZeigeAdresse();
        }
    }
}