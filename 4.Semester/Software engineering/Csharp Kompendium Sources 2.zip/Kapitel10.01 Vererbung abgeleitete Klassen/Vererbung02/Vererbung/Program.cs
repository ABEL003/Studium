﻿using System;

namespace Vererbung
{
    class Program
    {
        static void Main(string[] args)
        {
            var student = new Student("Freie Universität Berlin", "Max", "Mustermann", "Musterstrasse 6",
            "12345", "Musterhausen");

            student.ZeigeStudent();
        }
    }
}