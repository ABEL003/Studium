﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ErstesLinqBeispiel
{
    class Program
    {
        static void Main(string[] args)
        {
            var Woche = new List<string> { "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag" };

            var tageMitM = Woche.Where(t => t.StartsWith("M"));

            foreach (var tag in tageMitM)
            {
                Console.WriteLine(tag);
            }
        }
    }
}
