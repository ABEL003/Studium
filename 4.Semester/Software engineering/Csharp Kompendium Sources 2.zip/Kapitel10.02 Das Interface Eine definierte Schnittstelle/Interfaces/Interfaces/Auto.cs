﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Interfaces
{
    public class Auto : IFahrbar
    {
        public Auto()
        {
            Typ = "Auto";
            AnzahlRaeder = 4;
        }

        public string Typ { get; }

        public int AnzahlRaeder { get; }

        public void Fahren()
        {
            Console.WriteLine($"Ich bin ein {Typ} und fahre auf {AnzahlRaeder} Rädern.");
        }
    }
}