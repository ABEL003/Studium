﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Interfaces
{
    public class Motorrad : IFahrbar
    {
        public Motorrad()
        {
            Typ = "Motorrad";
            AnzahlRaeder = 2;
        }

        public string Typ { get; }

        public int AnzahlRaeder { get; }

        public void Fahren()
        {
            Console.WriteLine($"Ich bin ein {Typ} und fahre auf {AnzahlRaeder} Rädern.");
        }
    }
}
