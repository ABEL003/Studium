﻿using System.Text;

namespace Interfaces
{
    public interface IFahrbar
    {

        string Typ { get; }

        int AnzahlRaeder { get; }

        void Fahren();
    }
}