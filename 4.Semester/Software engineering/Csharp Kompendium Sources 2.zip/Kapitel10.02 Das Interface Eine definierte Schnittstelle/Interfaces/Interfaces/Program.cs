﻿using System;
using System.Collections.Generic;

namespace Interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            IFahrbar motorrad = new Fahrzeugfabrik(FahrzeugTyp.Motorrad).ErzeugeFahrzeug();
            IFahrbar auto = new Fahrzeugfabrik(FahrzeugTyp.Auto).ErzeugeFahrzeug();

            var fahrzeuge = new List<IFahrbar>();
            fahrzeuge.Add(motorrad);
            fahrzeuge.Add(auto);

            foreach (var fahrzeug in fahrzeuge)
            {
                fahrzeug.Fahren();
            }
        }
    }
}