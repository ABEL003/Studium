﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Interfaces
{
    public enum FahrzeugTyp
    {
        Auto,
        Motorrad
    }

    public class Fahrzeugfabrik
    {
        private FahrzeugTyp fahrzeugTyp;

        public Fahrzeugfabrik(FahrzeugTyp fahrzeugTyp)
        {
            this.fahrzeugTyp = fahrzeugTyp;
        }

        public IFahrbar ErzeugeFahrzeug()
        {
            if (fahrzeugTyp == FahrzeugTyp.Motorrad)
            {
                return new Motorrad();
            }

            return new Auto();
        }
    }
}
