﻿using System;
using System.Linq;
using System.Threading;

namespace Linqtutorials
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] intWerte = Enumerable.Range(1, 10000).
            ToArray();

            var startZeit = DateTime.Now.Ticks;
            for (var i = 0; i < intWerte.Length; i++)
            {
                Thread.Sleep(1);
            }
            Console.WriteLine($"Verarbeitungszeit mit klassischem Linq: {TimeSpan.FromTicks(DateTime.Now.Ticks - startZeit).TotalMilliseconds}ms ");

            startZeit = DateTime.Now.Ticks;
            intWerte.AsParallel().ForAll((wert) => Thread.

            Sleep(1));
            Console.WriteLine($"Verarbeitungszeit mit ParallelLinq: {TimeSpan.FromTicks(DateTime.Now.Ticks - startZeit).TotalMilliseconds}ms");
        }
    }
}