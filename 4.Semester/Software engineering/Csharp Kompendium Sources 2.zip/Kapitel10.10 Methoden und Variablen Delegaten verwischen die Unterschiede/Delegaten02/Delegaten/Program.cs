﻿using System;

namespace Delegaten
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program().Start();
        }

        public void Start()
        {
            var a = 2;
            var b = 3;

            Func<int, int, int> Rechne = (a, b) => a + b;
            var summe = Rechne(a, b);

            Rechne = (a, b) => a * b;

            var produkt = Rechne(a, b);

            Console.WriteLine($"{a} + {b} = {summe}");
            Console.WriteLine($"{a} * {b} = {produkt}");
        }
    }
}
