﻿using System;

namespace Delegaten
{
    public delegate int Kalkulation(int a, int b);

    class Program
    {

        static void Main(string[] args)
        {
            new Program().Start();
        }

        public void Start()
        {
            var a = 2;
            var b = 3;

            Kalkulation Rechne;

            Rechne = Addiere;
            var summe = Rechne(a, b);

            Rechne = Multipliziere;
            var produkt = Rechne(a, b);

            Console.WriteLine($"{a} + {b} = {summe}");
            Console.WriteLine($"{a} * {b} = {produkt}");
        }

        private int Addiere(int a, int b)
        {
            return a + b;
        }

        private int Multipliziere(int a, int b)
        {
            return a * b;
        }
    }
}