﻿using System;

namespace GenerischeMethoden
{
    class Program
    {
        static void Main(string[] args)
        {
            var string1 = "string1";
            var string2 = "string2";

            Console.WriteLine("Vor dem Vertauschen:");
            Console.WriteLine($"{string1}, {string2}");

            var meineKlasse = new MeineKlasse();
            meineKlasse.Vertausche(ref string1, ref string2);

            Console.WriteLine("Nach dem Vertauschen:");
            Console.WriteLine($"{string1}, {string2}");
        }
    }
}
