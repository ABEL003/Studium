﻿using System;

namespace GenerischeMethoden
{
    class Program
    {
        static void Main(string[] args)
        {
            var integer1 = 1;
            var integer2 = 2;

            Console.WriteLine("Vor dem Vertauschen:");
            Console.WriteLine($"{integer1}, {integer2}");

            var meineKlasse = new MeineKlasse();
            meineKlasse.Vertausche(ref integer1, ref integer2);

            Console.WriteLine("Nach dem Vertauschen: ");
            Console.WriteLine($"{integer1}, {integer2}");
        }
    }
}