﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenerischeMethoden
{
    public class MeineKlasse
    {
        public void Vertausche<T>(ref T parameter1,
        ref T parameter2)
        {
            T merke = parameter1;
            parameter1 = parameter2;
            parameter2 = merke;
        }
    }
}