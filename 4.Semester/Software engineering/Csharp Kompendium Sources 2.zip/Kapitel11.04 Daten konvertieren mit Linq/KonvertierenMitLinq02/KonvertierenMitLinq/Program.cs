﻿using System;
using System.Linq;

namespace KonvertierenMitLinq
{
    class Program
    {
        static void Main(string[] args)

        {

            var personen = Person.AllePersonen.Select(p => new { p.Vorname, p.Nachname });

            foreach (var person in personen)
            {
                Console.WriteLine($"{person.Vorname} {person.Nachname}");
            }
        }
    }
}