﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonvertierenMitLinq
{
    public class Person
    {
        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public static List<Person> AllePersonen
        {
            get
            {
                return new List<Person>
                {
                new Person
                {
                    Vorname = "Max",
                    Nachname = "Mustermann"
                },
                new Person
                {
                    Vorname = "Marta",
                    Nachname = "Musterfrau"
                }
                };
            }
        }
    }
}