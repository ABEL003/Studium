﻿using System;
using System.Linq;

namespace KonvertierenMitLinq
{
    class Program
    {
        static void Main(string[] args)
        {
            var adressen = Person.AllePersonen.Where(p =>
            p.Nachname.StartsWith("M")).Select(p => new Adresse
            { Ort = p.Ort, Strasse = p.Strasse });

            foreach (var adresse in adressen)
            {
                Console.WriteLine(adresse);
            }
        }
    }
}