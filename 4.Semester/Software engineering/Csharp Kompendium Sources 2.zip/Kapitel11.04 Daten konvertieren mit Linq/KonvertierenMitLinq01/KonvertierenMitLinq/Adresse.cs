﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonvertierenMitLinq
{
    public class Adresse
    {
        public string Ort { get; set; }
        public string Strasse { get; set; }

        public override string ToString()
        {
            return $"{Ort} {Strasse}";
        }
    }
}