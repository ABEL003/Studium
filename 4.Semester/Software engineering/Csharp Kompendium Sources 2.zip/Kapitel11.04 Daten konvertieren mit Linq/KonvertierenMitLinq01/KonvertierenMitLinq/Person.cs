﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonvertierenMitLinq
{
    public class Person : Adresse
    {
        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public static List<Person> AllePersonen
        {
            get
            {
                return new List<Person>
                {
                new Person
                {
                    Vorname = "Max",
                    Nachname = "Mustermann",
                    Ort = "Musterhausen",
                    Strasse = "Musterstr. 1"
                },
                new Person
                {
                    Vorname = "Marta",
                    Nachname = "Musterfrau",
                    Ort = "Musterstadt",
                    Strasse = "Musterweg 7"
                }
                };
            }
        }
    }
}