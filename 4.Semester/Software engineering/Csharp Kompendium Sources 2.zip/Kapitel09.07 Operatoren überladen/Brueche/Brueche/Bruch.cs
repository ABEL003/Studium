﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Brueche
{
    public class Bruch
    {
        public int Zaehler { get; set; }
        public int Nenner { get; set; }

        public Bruch(int zaehler, int nenner)
        {
            Zaehler = zaehler;
            Nenner = nenner;
        }

        public static Bruch operator +(Bruch a)
        {
            return a;
        }

        public static Bruch operator -(Bruch a)
        {
            return new Bruch(-a.Zaehler, a.Nenner);
        }

        public static Bruch operator +(Bruch a, Bruch b)
        {
            return new Bruch(a.Zaehler * b.Nenner + b.Zaehler * a.Nenner, a.Nenner * b.Nenner);
        }

        public static Bruch operator -(Bruch a, Bruch b)
        {
            return a + (-b);
        }

        public static Bruch operator *(Bruch a, Bruch b)
        {
            return new Bruch(a.Zaehler * b.Zaehler, a.Nenner * b.Nenner);
        }

        public static Bruch operator /(Bruch a, Bruch b)
        {
            return new Bruch(a.Zaehler * b.Nenner, a.Nenner * b.Zaehler);
        }
    }
}