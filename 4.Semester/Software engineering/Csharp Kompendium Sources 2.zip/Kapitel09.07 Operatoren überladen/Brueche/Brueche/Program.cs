﻿using System;

namespace Brueche
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = new Bruch(1, 2);
            var b = new Bruch(1, 4);

            var plusa = +a;
            var minusa = -a;
            var summe = a + b;
            var differenz = a - b;
            var produkt = a * b;
            var quotient = a / b;

            Console.WriteLine($"a = {a.Zaehler}/{a.Nenner}");
            Console.WriteLine($"b = {b.Zaehler}/{b.Nenner}");
            Console.WriteLine($"+a = {plusa.Zaehler}/{plusa.Nenner}");
            Console.WriteLine($"-a = {minusa.Zaehler}/{minusa.Nenner}");
            Console.WriteLine($"a + b = {summe.Zaehler}/{summe.Nenner}");
            Console.WriteLine($"a - b = {differenz.Zaehler}/{ differenz.Nenner}");
            Console.WriteLine($"a * b = {produkt.Zaehler}/{ produkt.Nenner}");
            Console.WriteLine($"a / b = {quotient.Zaehler}/{ quotient.Nenner}");
        }
    }
}