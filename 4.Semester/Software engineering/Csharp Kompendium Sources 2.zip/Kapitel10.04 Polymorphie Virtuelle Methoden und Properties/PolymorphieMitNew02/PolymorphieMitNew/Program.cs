﻿using System;
using System.Collections.Generic;


namespace PolymorphieMitNew
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<string> liste = new NeueStringListe();
            liste.Add("Hello World");
        }
    }
}