﻿using System;
using System.Collections.Generic;

namespace Polymorphie
{
    class Program
    {
        static void Main(string[] args)
        {
            Adresse adresse = new Person("Max", "Mustermann",
            "Musterhausen", "Musterstraße 1");
            Person person = (Person)adresse;

            Console.WriteLine(person.Nachname);

        }
    }
}