﻿using System;

namespace VirtuelleProperties
{
    class Program
    {
        static void Main(string[] args)
        {
            var person = new Person
            {
                Vorname = "Robert",
                Nachname = "Schiefele"
            };

            var personMitTitel = new PersonMitTitel
            {
                Vorname = "Gustav",
                Nachname = "Müller-Lüdenscheid",
                Titel = "Dr."
            };

            Console.WriteLine(person.Briefanrede);
            Console.WriteLine(personMitTitel.Briefanrede);
        }
    }
}