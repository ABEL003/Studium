﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtuelleProperties
{
    public class PersonMitTitel : Person
    {
        public string Titel { get; set; }
        public override string Briefanrede
        {
            get
            {
                return $"Sehr geehrter Herr {Titel} {Nachname},";
            }
        }
    }
}
