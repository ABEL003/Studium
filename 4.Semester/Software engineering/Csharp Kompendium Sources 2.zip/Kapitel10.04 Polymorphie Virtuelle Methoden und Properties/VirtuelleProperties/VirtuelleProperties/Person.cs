﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtuelleProperties
{
    public class Person
    {
        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public virtual string Briefanrede
        {
            get
            {
                return $"Sehr geehrter Herr {Nachname},";
            }
        }
    }

}
