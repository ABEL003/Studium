﻿using System.Collections.Generic;

namespace Polymorphie
{
    class Program
    {
        static void Main(string[] args)
        {
            var adresse = new Adresse("Neustadt", "Hauptstrasse 25");
            var person = new Person("Max", "Mustermann", "Musterhausen", "Musterstraße 1");

            var adressListe = new List<Adresse>();

            adressListe.Add(adresse);
            adressListe.Add(person);

            foreach (var element in adressListe)
            {
                element.Ausgabe();
            }
        }
    }
}