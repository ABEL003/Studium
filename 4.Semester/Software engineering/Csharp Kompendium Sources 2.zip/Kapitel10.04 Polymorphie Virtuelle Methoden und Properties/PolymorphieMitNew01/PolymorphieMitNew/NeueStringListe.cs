﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PolymorphieMitNew
{
    public class NeueStringListe : List<string>
    {
        public new void Add(string item)
        {
            base.Add(item);
            Console.WriteLine($"\"{item}\" wurde der Liste hinzugefügt.");
        }
    }
}