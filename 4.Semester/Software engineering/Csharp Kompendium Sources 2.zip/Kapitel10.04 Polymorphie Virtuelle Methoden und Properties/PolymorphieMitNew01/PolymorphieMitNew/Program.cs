﻿using System;
using System.Collections.Generic;

namespace PolymorphieMitNew
{
    public class Program
    {
        static void Main(string[] args)
        {
            var liste = new NeueStringListe();
            liste.Add("Hello");
            liste.Add("World");
        }
    }
}