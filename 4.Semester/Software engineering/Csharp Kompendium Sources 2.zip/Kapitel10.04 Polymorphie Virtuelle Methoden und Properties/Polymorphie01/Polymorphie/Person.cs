﻿using System;

namespace Polymorphie
{
    public class Person : Adresse
    {
        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public Person(string vorname, string nachname,
        string ort, string strasse) : base(ort, strasse)
        {
            Vorname = vorname;
            Nachname = nachname;
        }

        public void AusgabePerson()
        {
            Console.WriteLine($"{Vorname} {Nachname}");
            AusgabeAdresse();
        }
    }
}