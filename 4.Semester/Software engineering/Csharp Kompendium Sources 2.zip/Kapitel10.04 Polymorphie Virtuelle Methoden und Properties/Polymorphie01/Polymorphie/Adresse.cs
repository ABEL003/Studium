﻿using System;

namespace Polymorphie
{
    public class Adresse
    {
        public string Ort { get; set; }
        public string Strasse { get; set; }

        public Adresse(string ort, string strasse)
        {
            Ort = ort;
            Strasse = strasse;
        }

        public void AusgabeAdresse()
        {
            Console.WriteLine(Strasse);
            Console.WriteLine(Ort);
        }
    }
}

