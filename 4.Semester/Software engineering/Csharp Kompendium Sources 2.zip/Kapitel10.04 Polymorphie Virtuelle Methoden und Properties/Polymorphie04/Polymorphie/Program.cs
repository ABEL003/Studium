﻿using System;
using System.Collections.Generic;

namespace Polymorphie
{
    class Program
    {
        static void Main(string[] args)
        {
            Adresse objekt1 = new Adresse("Musterhausen", "Musterstraße 1");
            Person objekt2 = new Person("Max", "Mustermann", "Musterhausen", "Musterstraße 1");

            UntersucheObjekt("objekt1", objekt1);
            UntersucheObjekt("objekt2", objekt2);
        }

        static void UntersucheObjekt(string name, Adresse obj)
        {
            Person person = obj as Person;
            if (person == null)
            {
                Console.WriteLine($"Das Objekt {name} hat den Typ Adresse");
            }
            else
            {
                Console.WriteLine($"Das Objekt {name} hat den Typ Person");
            }
        }
    }
}