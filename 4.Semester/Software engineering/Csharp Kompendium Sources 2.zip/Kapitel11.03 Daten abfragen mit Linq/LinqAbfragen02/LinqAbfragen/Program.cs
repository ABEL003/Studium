﻿using System;
using System.Linq;

namespace LinqAbfragen
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Person.AllePersonen.Any());
            Console.WriteLine(Person.AllePersonen.Any(p =>
            p.Vorname.StartsWith("X")));
        }
    }
}