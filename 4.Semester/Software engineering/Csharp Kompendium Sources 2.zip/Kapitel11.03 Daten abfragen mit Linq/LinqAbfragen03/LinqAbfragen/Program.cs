﻿using System;
using System.Linq;

namespace LinqAbfragen
{
    class Program
    {
        static void Main(string[] args)
        {
            var alleAutos = Person.AllePersonen.SelectMany(p => p.Autos);
            foreach (var auto in alleAutos)
            {
                Console.WriteLine(auto);
            }
        }
    }
}
