﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinqAbfragen
{
    public class Auto
    {
        public Auto(string marke, string modell)
        {
            Marke = marke;
            Modell = modell;
        }

        public string Marke;
        public string Modell;

        public override string ToString()
        {
            return $"{Marke} {Modell}";
        }
    }
}