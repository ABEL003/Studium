﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinqAbfragen
{
    public class Person
    {
        public Person(string vorname, string nachname)
        {
            Vorname = vorname;
            Nachname = nachname;
            Autos = new List<Auto>();
        }

        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public List<Auto> Autos { get; }

        public override string ToString()
        {
            return $"{Vorname} {Nachname}";
        }

        public static List<Person> AllePersonen
        {
            get
            {
                var personen = new List<Person>();
                var auto1 = new Auto("Ford", "Focus");
                var auto2 = new Auto("VW", "Golf");
                var auto3 = new Auto("Opel", "Astra");
                var auto4 = new Auto("Fiat", "Punto");
                var auto5 = new Auto("Renault", "Megane");
                var auto6 = new Auto("Seat", "Leon");

                var person1 = new Person("Lisa", "Müller");
                person1.Autos.Add(auto1);
                person1.Autos.Add(auto2);

                var person2 = new Person("Robert", "Schiefele");
                person2.Autos.Add(auto3);
                person2.Autos.Add(auto4);

                var person3 = new Person("Jacqueline", "Meier");
                person3.Autos.Add(auto5);
                person3.Autos.Add(auto6);

                personen.Add(person1);
                personen.Add(person2);
                personen.Add(person3);

                return personen;
            }
        }
    }
}