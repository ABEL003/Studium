﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinqAbfragen
{
    using System;
    using System.Collections.Generic;
    using System.Text;


    public class Person
    {
        public Person(string vorname, string nachname)
        {
            Vorname = vorname;
            Nachname = nachname;
        }

        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public override string ToString()
        {
            return $"{Vorname} {Nachname}";
        }

        public static List<Person> AllePersonen
        {
            get
            {
                var personen = new List<Person>();

                personen.Add(new Person("Konrad", "Zuse"));
                personen.Add(new Person("Grace", "Hopper"));
                personen.Add(new Person("Ada", "Lovlace"));
                personen.Add(new Person("Alan", "Turing"));
                personen.Add(new Person("Charles", "Babbage"));
                personen.Add(new Person("Rósza", "Péter"));
                personen.Add(new Person("Herrman", "Holerith"));
                personen.Add(new Person("Hedy", "Lamarr"));
                personen.Add(new Person("Edgar F.", "Codd"));
                personen.Add(new Person("Marlyn", "Meltzer"));
                personen.Add(new Person("Heinz", "Nixdorf"));
                personen.Add(new Person("Gertrude", "Blanch"));

                return personen;
            }
        }
    }
}
