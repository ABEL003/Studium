﻿using System;
using System.Linq;

namespace LinqAbfragen
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Person.AllePersonen.First());
            Console.WriteLine(Person.AllePersonen.First(p => p.Vorname.StartsWith("A")));
        }
    }
}