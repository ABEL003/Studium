﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Baumstrukturen
{
    public class Knoten
    {
        private int tiefe;
        private string einrueckung;
        private string baumausgabe;

        public Knoten(string name)
        {
            Name = name;
            Unterknoten = new List<Knoten>();
        }
        public string Name { get; set; }

        public List<Knoten> Unterknoten { get; set; }

        public override string ToString()
        {
            tiefe = 0;
            baumausgabe = "";
            SetzeEinrueckung();

            BaumAusgabeRekursiv(this);
            return baumausgabe;

        }

        private void BaumAusgabeRekursiv(Knoten knoten)
        {
            baumausgabe += $"{einrueckung}{knoten.Name}\r\n";

            if (Unterknoten.Count > 0)
            {
                tiefe++;
                SetzeEinrueckung();

                foreach (var unterknoten in knoten.Unterknoten)
                {
                    BaumAusgabeRekursiv(unterknoten);
                }

                tiefe--;
                SetzeEinrueckung();
            }
        }

        private void SetzeEinrueckung()
        {
            einrueckung = "";
            for (var i = 0; i < tiefe; i++)
            {
                einrueckung += " ";
            }
        }
    }
}