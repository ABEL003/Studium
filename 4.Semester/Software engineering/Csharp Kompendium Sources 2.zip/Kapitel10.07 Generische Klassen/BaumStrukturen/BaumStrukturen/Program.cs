﻿using System;

namespace Baumstrukturen
{
    class Program
    {
        static void Main(string[] args)
        {
            //Instanzieren der Knoten
            var wurzel = new Knoten("Wurzelknoten");
            var knoten1 = new Knoten("Knoten1");
            var knoten11 = new Knoten("Knoten11");
            var knoten12 = new Knoten("Knoten12");
            var knoten2 = new Knoten("Knoten2");
            var knoten21 = new Knoten("Knoten21");
            var knoten22 = new Knoten("Knoten22");

            //Untereinanderhängen der Knoten
            knoten1.Unterknoten.Add(knoten11);
            knoten1.Unterknoten.Add(knoten12);
            knoten2.Unterknoten.Add(knoten21);
            knoten2.Unterknoten.Add(knoten22);
            wurzel.Unterknoten.Add(knoten1);
            wurzel.Unterknoten.Add(knoten2);

            //Baumstruktur am Bild schirmausgeben
            Console.WriteLine(wurzel);
        }
    }
}
