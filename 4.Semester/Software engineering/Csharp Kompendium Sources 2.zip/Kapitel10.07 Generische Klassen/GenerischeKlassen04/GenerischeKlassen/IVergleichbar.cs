﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenerischeKlassen
{
    public interface IVergleichbar<T>
    {
        bool IstGleich(T einObjekt);
    }
}

