﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenerischeKlassen
{
    public class Person : IVergleichbar<Person>
    {
        public Person(string vorname, string nachname)
        {
            Vorname = vorname;
            Nachname = nachname;
        }

        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public override string ToString()
        {
            return $"{Vorname} {Nachname}";
        }

        public bool IstGleich(Person einObjekt)
        {
            if (einObjekt.Vorname == Vorname &&
            einObjekt.Nachname == Nachname)
            {
                return true;
            }
            return false;
        }
    }
}