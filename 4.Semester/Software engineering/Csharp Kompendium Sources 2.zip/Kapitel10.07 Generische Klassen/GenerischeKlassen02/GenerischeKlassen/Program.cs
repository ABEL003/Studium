﻿using System;

namespace GenerischeKlassen
{
    class Program
    {
        static void Main(string[] args)
        {
            var wurzel = new Knoten<string>("Wurzel");
            var knoten1 = new Knoten<string>("Knoten1");
            var knoten11 = new Knoten<string>("Knoten11");
            var knoten12 = new Knoten<string>("Knoten12");
            var knoten2 = new Knoten<string>("Knoten2");
            var knoten21 = new Knoten<string>("Knoten21");
            var knoten22 = new Knoten<string>("Knoten22");

            knoten1.UnterKnoten.Add(knoten11);
            knoten1.UnterKnoten.Add(knoten12);
            knoten2.UnterKnoten.Add(knoten21);
            knoten2.UnterKnoten.Add(knoten22);

            wurzel.UnterKnoten.Add(knoten1);
            wurzel.UnterKnoten.Add(knoten2);

            Console.WriteLine(wurzel.Finde("Knoten2"));
        }
    }
}