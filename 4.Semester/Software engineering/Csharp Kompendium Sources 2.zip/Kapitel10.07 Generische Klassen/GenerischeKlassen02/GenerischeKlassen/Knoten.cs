﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenerischeKlassen
{
    public class Knoten<T>
    {
        private T daten;

        private int tiefe;
        private string einrueckung;
        private string baumausgabe;

        public Knoten(T daten)
        {
            this.daten = daten;
            UnterKnoten = new List<Knoten<T>>();
        }

        public List<Knoten<T>> UnterKnoten;

        public override string ToString()
        {
            tiefe = 0;
            baumausgabe = "";
            SetzeEinrueckung();

            BaumAusgabeRekursiv(this);
            return baumausgabe;
        }

        private void BaumAusgabeRekursiv(Knoten<T> knoten)
        {

            baumausgabe += $"{einrueckung}{knoten.daten}\r\n";

            if (UnterKnoten.Count > 0)
            {
                tiefe++;
                SetzeEinrueckung();

                foreach (var unterknoten in knoten.UnterKnoten)
                {
                    BaumAusgabeRekursiv(unterknoten);
                }

                tiefe--;
                SetzeEinrueckung();
            }
        }

        public Knoten<T> Finde(T nutzDaten)
        {
            return FindeRekursiv(this, nutzDaten);
        }

        public Knoten<T> FindeRekursiv(Knoten<T> knoten,
        T nutzDaten)
        {
            if (knoten.daten.Equals(nutzDaten))
            {
                return knoten;
            }
            else
            {
                foreach (var unterknoten in knoten.UnterKnoten)
                {
                    var ergebnis = FindeRekursiv(unterknoten,
                    nutzDaten);
                    if (ergebnis != null)
                    {
                        return ergebnis;
                    }
                }
            }

            return null;
        }

        private void SetzeEinrueckung()
        {
            einrueckung = "";
            for (int i = 0; i < tiefe; i++)
            {
                einrueckung += " ";
            }
        }
    }
}
