﻿using System;

namespace ToStringUeberschreiben
{
    class Program
    {
        static void Main(string[] args)
        {
            var person = new Person("Robert", "Schiefele");
            Console.WriteLine(person);
        }
    }
}