﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ToStringUeberschreiben
{
    public class Person
    {
        public Person(string vorname, string nachname)
        {
            Vorname = vorname;
            Nachname = nachname;
        }

        string Vorname { get; set; }
        string Nachname { get; set; }

        public override string ToString()
        {
            return $"{Vorname} {Nachname}";
        }
    }
}
