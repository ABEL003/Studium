﻿using System;

namespace GenerischeKlassen
{
    class Program
    {
        static void Main(string[] args)
        {
            var personWurzel = new Knoten<Person>(new
             Person("Robert", "Schiefele"));
            var personKnoten1 = new Knoten<Person>(new
            Person("Max", "Mustermann"));
            var personKnoten11 = new Knoten<Person>(new
            Person("Theo", "Tester"));
            var personKnoten12 = new Knoten<Person>(new
            Person("Thea", "Testerin"));
            var personKnoten2 = new Knoten<Person>(new
            Person("Anna", "Müller"));
            var personKnoten21 = new Knoten<Person>(new
            Person("Fritz", "Fischer"));
            var personKnoten22 = new Knoten<Person>(new
            Person("Erna", "Müller"));

            personKnoten1.UnterKnoten.Add(personKnoten11);
            personKnoten1.UnterKnoten.Add(personKnoten12);

            personKnoten2.UnterKnoten.Add(personKnoten21);
            personKnoten2.UnterKnoten.Add(personKnoten22);

            personWurzel.UnterKnoten.Add(personKnoten1);
            personWurzel.UnterKnoten.Add(personKnoten2);

            Console.WriteLine(personWurzel);
        }
    }
}