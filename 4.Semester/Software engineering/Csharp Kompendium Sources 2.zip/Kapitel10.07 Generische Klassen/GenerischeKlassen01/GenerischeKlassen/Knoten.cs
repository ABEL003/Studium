﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenerischeKlassen
{
    public class Knoten<T>
    {
        private T daten;

        private int tiefe;
        private string einrueckung;
        private string baumausgabe;

        public Knoten(T daten)
        {
            this.daten = daten;
            UnterKnoten = new List<Knoten<T>>();
        }

        public List<Knoten<T>> UnterKnoten;

        public override string ToString()
        {
            tiefe = 0;
            baumausgabe = "";
            SetzeEinrueckung();

            BaumAusgabeRekursiv(this);
            return baumausgabe;
        }

        private void BaumAusgabeRekursiv(Knoten<T> knoten)
        {

            baumausgabe += $"{einrueckung}{knoten.daten}\r\n";

            if (UnterKnoten.Count > 0)
            {
                tiefe++;
                SetzeEinrueckung();

                foreach (var unterknoten in knoten.UnterKnoten)
                {
                    BaumAusgabeRekursiv(unterknoten);
                }

                tiefe--;
                SetzeEinrueckung();
            }
        }

        private void SetzeEinrueckung()
        {
            einrueckung = "";
            for (int i = 0; i < tiefe; i++)
            {
                einrueckung += " ";
            }
        }
    }
}
