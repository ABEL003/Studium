﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenerischeKlassen
{
    public class Person
    {
        public Person(string vorname, string nachname)
        {
            Vorname = vorname;
            Nachname = nachname;
        }

        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public override string ToString()
        {
            return $"{Vorname} {Nachname}";
        }
    }
}