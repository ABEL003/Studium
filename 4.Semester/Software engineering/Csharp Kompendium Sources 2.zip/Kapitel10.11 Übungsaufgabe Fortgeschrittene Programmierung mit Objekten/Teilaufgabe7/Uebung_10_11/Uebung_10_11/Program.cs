﻿using System;

namespace Uebung_10_11
{
    class Program
    {
        static void Main(string[] args)
        {
            var oeWurzel = new OrgEinheit("OrgEinheit1");
            oeWurzel.OeLeitung = new Mitarbeiter("Leiter", "OE1", "Chefbüro OE1");
            oeWurzel.NeuerMitarbeiter(new Mitarbeiter("MA1", "OE1", "Büro1 OE1"));
            oeWurzel.NeuerMitarbeiter(new Mitarbeiter("MA2", "OE1", "Büro2 OE1"));

            var oe11 = new OrgEinheit("OrgEinheit11");
            oe11.OeLeitung = new Mitarbeiter("Leiter", "OE11", "Chefbüro OE11");
            oe11.NeuerMitarbeiter(new Mitarbeiter("MA1", "OE11", "Büro1 OE11"));
            oe11.NeuerMitarbeiter(new Mitarbeiter("MA2", "OE11", "Büro2 OE11"));

            var oe12 = new OrgEinheit("OrgEinheit12");
            oe12.OeLeitung = new Mitarbeiter("Leiter", "OE12", "Chefbüro OE12");
            oe12.NeuerMitarbeiter(new Mitarbeiter("MA1", "OE12", "Büro1 OE12"));
            oe12.NeuerMitarbeiter(new Mitarbeiter("MA2", "OE12", "Büro2 OE12"));

            oeWurzel.Untereinheiten.Add(oe11);
            oeWurzel.Untereinheiten.Add(oe12);

            var mitarbeiterListe = oeWurzel.
            ErstelleListeAllerMitarbeiter();

            foreach (var mitarbeiter in mitarbeiterListe)
            {
                Console.WriteLine($"{mitarbeiter} ({mitarbeiter.OrganisationsEinheit.Name})");
            }

            var ergebnis = oeWurzel.SucheOrgEinheitAls(
                oe => oe.OeLeitung,
                oe => oe.Kollegen.Contains(new Mitarbeiter("MA1", "OE12", "Büro1 OE12")));

            Console.WriteLine(ergebnis);
        }
    }
}

