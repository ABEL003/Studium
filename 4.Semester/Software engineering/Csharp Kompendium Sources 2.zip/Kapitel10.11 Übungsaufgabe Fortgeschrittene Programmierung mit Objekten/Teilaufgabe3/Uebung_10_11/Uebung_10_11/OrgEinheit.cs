﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung_10_11
{
    public class OrgEinheit
    {
        public string Name { get; set; }
        public Mitarbeiter OeLeitung { get; set; }
        public List<Mitarbeiter> Kollegen { get; set; }

        public List<OrgEinheit> Untereinheiten { get; set; }

        public OrgEinheit(string name)
        {
            Name = name;
            Kollegen = new List<Mitarbeiter>();
            Untereinheiten = new List<OrgEinheit>();
        }

    }
}
