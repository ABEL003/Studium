﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Uebung_10_11
{
    public class Person : IEquatable<Person>
    {
        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public Person(string vorname, string nachname)
        {
            Vorname = vorname;
            Nachname = nachname;
        }

        public bool Equals(Person other)
        {
            return Vorname == other.Vorname && Nachname ==
            other.Nachname;
        }

        public override string ToString()
        {
            return $"{Vorname} {Nachname}";
        }
    }
}

