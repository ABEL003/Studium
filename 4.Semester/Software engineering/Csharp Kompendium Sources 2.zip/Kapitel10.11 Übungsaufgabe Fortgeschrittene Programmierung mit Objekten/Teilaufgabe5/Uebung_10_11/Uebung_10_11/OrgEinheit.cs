﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung_10_11
{
    public class OrgEinheit
    {
        public string Name { get; set; }
        public Mitarbeiter OeLeitung { get; set; }
        public List<Mitarbeiter> Kollegen { get; set; }

        public List<OrgEinheit> Untereinheiten { get; set; }

        public OrgEinheit(string name)
        {
            Name = name;
            Kollegen = new List<Mitarbeiter>();
            Untereinheiten = new List<OrgEinheit>();
        }

        public void NeuerMitarbeiter(Mitarbeiter mitarbeiter)
        {
            mitarbeiter.OrganisationsEinheit = this;
            Kollegen.Add(mitarbeiter);
        }

        public List<Mitarbeiter> ErstelleListeAllerMitarbeiter()
        {
            return ErstelleListeAllerMitarbeiterRekursiv(this);
        }

        private List<Mitarbeiter>
        ErstelleListeAllerMitarbeiterRekursiv(OrgEinheit orgeinheit)
        {
            var mitarbeiterListe = new List<Mitarbeiter>();
            mitarbeiterListe.AddRange(orgeinheit.Kollegen);

            foreach (var untereinheit in orgeinheit.Untereinheiten)
            {
                mitarbeiterListe.AddRange(ErstelleListeAllerMitarbeiterRekursiv(untereinheit));
            }

            return mitarbeiterListe;
        }
    }
}
