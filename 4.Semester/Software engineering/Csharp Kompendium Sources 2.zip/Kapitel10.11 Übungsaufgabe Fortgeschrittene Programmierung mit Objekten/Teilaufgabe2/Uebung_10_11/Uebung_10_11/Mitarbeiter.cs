﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Uebung_10_11
{
    public class Mitarbeiter : Person, IEquatable<Mitarbeiter>
    {
        public string Arbeitsplatz { get; set; }

        public Mitarbeiter(string vorname, string nachname,
        string arbeitsplatz) : base(vorname, nachname)
        {
            Arbeitsplatz = arbeitsplatz;
        }

        public bool Equals(Mitarbeiter other)
        {
            return
            Arbeitsplatz == other.Arbeitsplatz &&
            Vorname == other.Vorname &&
            Nachname == other.Nachname;
        }

        public override string ToString()
        {
            return $"{base.ToString()} {Arbeitsplatz}";
        }
    }
}

