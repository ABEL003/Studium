﻿using System;
using System.Linq;

namespace AusfuerenVonLinqAbfragen
{
    class Program
    {
        static void Main(string[] args)
        {
            var arbeitsWoche = new string[]{ "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag" };
            var abfrageTageMitM = arbeitsWoche.Where(t => t.StartsWith("M"));
        }
    }
}
