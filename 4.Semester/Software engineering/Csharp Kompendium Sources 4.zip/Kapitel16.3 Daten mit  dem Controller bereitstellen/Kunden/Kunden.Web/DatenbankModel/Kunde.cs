﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Kunden.Web.DatenbankModel
{
    [Table("Kunde")]
    public class Kunde
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id")]
        public int KundeId { get; set; }

        [Required]
        [MaxLength(50)]
        [Column("firma")]
        public string Firma { get; set; }

        [MaxLength(50)]
        [Column("strasse")]
        public string Strasse { get; set; }

        [MaxLength(5)]
        [Column("plz")]
        public string PLZ { get; set; }

        [MaxLength(50)]
        [Column("ort")]
        public string Ort { get; set; }
    }

}