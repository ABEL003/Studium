﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kunden.Web.Models
{
    public class KundenListeViewModel
    {
        public IEnumerable<KundenViewModel> Kunden { get; set; }
    }
}