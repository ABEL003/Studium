﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kunden.Web.DatenbankModel;
using Kunden.Web.Models;
using Microsoft.AspNetCore.Mvc;

namespace Kunden.Web.Controllers
{
    public class KundenController : Controller
    {
        private KundenKontext kontext;

        public KundenController(KundenKontext kontext)
        {
            this.kontext = kontext;
        }

        public IActionResult Index()
        {
            var kundenListeViewModel = new KundenListeViewModel();
            kundenListeViewModel.Kunden = kontext.Kunden.Select(k =>KundenViewModel.AusEntity(k));
            return View(kundenListeViewModel);
        }
    }
}
