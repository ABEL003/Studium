using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Rechnung.Test
{
    [TestClass]
    public class RechenkernAusfuerungTest
    {
        private Mock<IRechenkern> rechenkernMock = new
         Mock<IRechenkern>();

        [TestMethod]
        public void RechenkernAusfuehrung1GibtRechne2zurueck()
        {
            //Arrange
            rechenkernMock.Setup(m => m.Rechne1()).Returns(-100);
            rechenkernMock.Setup(m => m.Rechne2()).Returns(100);
            var rechenkernAusfuehrung = new RechenkernAusfuehrung(rechenkernMock.Object);

            //Act
            var ergebnis = rechenkernAusfuehrung.Ausfuerung1();

            //Assert
            Assert.AreEqual(100, ergebnis);
        }

        [TestMethod]
        public void RechenkernAusfuerung2GibtNullZurueck()
        {
            //Arrange
            rechenkernMock.Setup(m => m.Rechne1()).Returns(-5);
            rechenkernMock.Setup(m => m.Rechne2()).Returns(5);
            var rechenkernAusfuehrung = new
            RechenkernAusfuehrung(rechenkernMock.Object);

            //Act
            var ergebnis = rechenkernAusfuehrung.Ausfuerung2();

            //Assert
            Assert.AreEqual(0, ergebnis);
        }
    }
}