﻿using System;

namespace Rechnung
{
    public interface IRechenkern
    {
        int Rechne1();

        int Rechne2();
    }
}