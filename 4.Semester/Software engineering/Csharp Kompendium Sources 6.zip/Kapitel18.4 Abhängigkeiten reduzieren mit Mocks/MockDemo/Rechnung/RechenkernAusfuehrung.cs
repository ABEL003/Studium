﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Rechnung
{
    public class RechenkernAusfuehrung
    {
        private IRechenkern rechenkern;

        public RechenkernAusfuehrung(IRechenkern rechenkern)
        {
            this.rechenkern = rechenkern;
        }

        public int Ausfuerung1()
        {
            var ergebnis = rechenkern.Rechne1();
            if (ergebnis < 0)
            {
                return rechenkern.Rechne2();
            }
            else
            {
                return ergebnis;
            }
        }

        public int Ausfuerung2()
        {
            var ergebnis = Ausfuerung1();
            if (ergebnis < 10 && ergebnis >= 0)
            {
                return rechenkern.Rechne1() + rechenkern.
                Rechne2();
            }
            else
            {
                return ergebnis;
            }
        }
    }
}