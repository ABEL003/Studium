using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DateiBetrachter.Test
{
    [TestClass]
    public class MainWindowViewModelTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
