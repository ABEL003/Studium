﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Forms;

namespace DateiBetrachter
{
    public class MainWindowViewModel : ViewModelBase
    {
        private string datei;
        private string ausgabe;
        private DateiListenElementViewModel ausgewaehlteDatei;

        public string Datei
        {
            get { return datei; }
            set
            {
                datei = value;
                OnPropertyChanged();
            }
        }

        public string Ausgabe
        {
            get { return ausgabe; }
            set
            {
                ausgabe = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<DateiListenElementViewModel> DateiListe { get; set; } = new ObservableCollection<DateiListenElementViewModel>();

        public DateiListenElementViewModel AusgewaehlteDatei
        {
            get { return ausgewaehlteDatei; }
            set
            {
                ausgewaehlteDatei = value;
                try
                {
                    Ausgabe = File.ReadAllText(AusgewaehlteDatei.
                    VollerName);
                    Datei = AusgewaehlteDatei.VollerName;
                }
                catch (Exception ex)
                {

                    Ausgabe = ex.Message;
                }
                OnPropertyChanged();
            }
        }

        public void VerzeichnisAuswahlClick(object sender, RoutedEventArgs e)
        {
            var folderBrowser = new FolderBrowserDialog();

            var result = folderBrowser.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {

                var ordnerInfo = new DirectoryInfo(folderBrowser.
                SelectedPath);
                if (ordnerInfo.Exists)
                {
                    DateiListe.Clear();
                    foreach (var dateiInfo in ordnerInfo.
                    GetFiles())
                    {
                        var dateiListenElement = new
                        DateiListenElementViewModel
                        {
                            Name = dateiInfo.Name,
                            VollerName = dateiInfo.ToString()
                        };

                        DateiListe.Add(dateiListenElement);
                    }
                }
            }
        }
    }
}