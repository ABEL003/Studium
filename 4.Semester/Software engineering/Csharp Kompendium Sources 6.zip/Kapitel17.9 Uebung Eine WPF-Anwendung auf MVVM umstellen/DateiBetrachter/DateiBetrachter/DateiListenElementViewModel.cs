﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DateiBetrachter
{
    public class DateiListenElementViewModel : ViewModelBase
    {
        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged();
            }
        }

        private string vollerName;

        public string VollerName
        {
            get { return vollerName; }
            set
            {
                vollerName = value;
                OnPropertyChanged();
            }
        }
    }
}