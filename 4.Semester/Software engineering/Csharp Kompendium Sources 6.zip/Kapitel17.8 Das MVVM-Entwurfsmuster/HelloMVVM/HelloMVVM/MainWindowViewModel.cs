﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;

namespace HelloMVVM
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler
        PropertyChanged;

        private string begruessung = "Hello World";
        public string Begruessung
        {
            get
            {
                return begruessung;
            }
            set
            {
                begruessung = value;
                OnPropertyChanged();
            }
        }

        public void OnButtonClick(object sender, RoutedEventArgs e)
        {
            Begruessung = "Hallo Welt";
        }

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new
                PropertyChangedEventArgs(propertyName));
            }
        }
    }
}