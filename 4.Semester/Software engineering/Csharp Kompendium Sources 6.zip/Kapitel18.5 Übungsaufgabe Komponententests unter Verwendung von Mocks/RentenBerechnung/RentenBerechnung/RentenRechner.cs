﻿using System;

namespace RentenBerechnung
{
    public class RentenRechner
    {
        ILebenserwartung lebenserwartung;

        public RentenRechner(ILebenserwartung lebenserwartung)
        {
            this.lebenserwartung = lebenserwartung;
        }

        public double BerechneRente(double einmalSumme, double
        alter)
        {
            var erwartetesAlter = lebenserwartung.BerechneLebensErwartung();

            if (alter >= erwartetesAlter)
            {
                throw new InvalidOperationException
                ("Rentenberechnung nicht möglich.");
            }

            return ((einmalSumme / (erwartetesAlter - alter)) / 12.0d) * 0.9d;
        }
    }
}