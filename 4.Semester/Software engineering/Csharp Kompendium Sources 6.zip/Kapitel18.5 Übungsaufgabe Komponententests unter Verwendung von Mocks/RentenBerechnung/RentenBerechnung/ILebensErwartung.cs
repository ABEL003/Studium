﻿using System;

namespace RentenBerechnung
{
    public interface ILebenserwartung
    {
        double BerechneLebensErwartung();
    }
}
