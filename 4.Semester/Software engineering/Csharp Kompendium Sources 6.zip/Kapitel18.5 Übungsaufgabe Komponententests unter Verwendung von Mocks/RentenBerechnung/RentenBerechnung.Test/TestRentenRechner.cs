using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;

namespace RentenBerechnung.Test
{
    [TestClass]
    public class TestRentenRechner
    {
        [TestMethod]
        public void BerechneRentePositivTest()
        {
            //Arrange
            var lebenserwartungMock = new Mock<ILebenserwartung>();
            lebenserwartungMock.Setup(m => m.BerechneLebensErwartung()).Returns(75);
            var rentenRechner = new RentenRechner(lebenserwartungMock.Object);

            //Act
            var rente = rentenRechner.BerechneRente(100000, 60);

            //Assert
            Assert.AreEqual(500.0, rente);
        }

        [TestMethod]
        public void BerechneRenteNegativTest()
        {
            //Arrange
            var lebenserwartungMock = new Mock<ILebenserwartung>();
            lebenserwartungMock.Setup(m => m.BerechneLebensErwartung()).Returns(75);
            var rentenRechner = new RentenRechner(lebenserwartungMock.Object);

            try
            {
                //Act
                var rente = rentenRechner.BerechneRente(100000, 80);
            }
            catch (InvalidOperationException ex)
            {
                //Assert
                Assert.AreEqual("Rentenberechnung nicht m�glich.", ex.Message);
            }
        }
    }
}