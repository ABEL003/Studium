using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;

namespace DateiBetrachter.Test
{
    [TestClass]
    public class MainWindowViewModelTest
    {
        [TestMethod]
        public void TestMainWindowViewModel()
        {
            var viewModel = new MainWindowViewModel();

            var dateiListenElement = new
            DateiListenElementViewModel();
            dateiListenElement.VollerName = @"TestDaten\Test.txt";
            dateiListenElement.Name = "Test.txt";
            viewModel.AusgewaehlteDatei = dateiListenElement;

            Assert.AreEqual("test", viewModel.Ausgabe);
            Assert.AreEqual(@"TestDaten\Test.txt", viewModel.
            Datei);
        }
    }
}