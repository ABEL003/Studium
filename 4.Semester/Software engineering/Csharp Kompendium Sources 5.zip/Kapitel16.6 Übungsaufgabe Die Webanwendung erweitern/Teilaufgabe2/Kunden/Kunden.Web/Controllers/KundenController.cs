﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kunden.Web.DatenbankModel;
using Kunden.Web.Models;
using Microsoft.AspNetCore.Mvc;

namespace Kunden.Web.Controllers
{
    public class KundenController : Controller
    {
        private KundenKontext kontext;

        public KundenController(KundenKontext kontext)
        {
            this.kontext = kontext;
        }

        public IActionResult Index()
        {
            var kundenListeViewModel = new KundenListeViewModel();
            kundenListeViewModel.Kunden = kontext.Kunden.Select(k => KundenViewModel.AusEntity(k));
            return View(kundenListeViewModel);
        }

        public IActionResult Aendern(int id)
        {
            var kunde = kontext.Kunden.First(k => k.KundeId == id);
            return View(KundenViewModel.AusEntity(kunde));
        }

        [HttpPost]
        public IActionResult Aendern([Bind("KundeId,Firma,Strasse,PLZ,Ort")] KundenViewModel kundeViewModel)
        {
            var kunde = kontext.Kunden.FirstOrDefault(k => k.KundeId ==
            kundeViewModel.KundeId);

            kunde.Firma = kundeViewModel.Firma;
            kunde.Strasse = kundeViewModel.Strasse;
            kunde.PLZ = kundeViewModel.PLZ;
            kunde.Ort = kundeViewModel.Ort;

            kontext.SaveChanges();

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Loeschen(int id)
        {
            var kunde = kontext.Kunden.First(k => k.KundeId == id);
            kontext.Kunden.Remove(kunde);
            kontext.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
