﻿using Kunden.Web.DatenbankModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kunden.Web.Models
{
    public class KundenViewModel
    {
        public int KundeId { get; set; }

        public string Firma { get; set; }

        public string Strasse { get; set; }

        public string PLZ { get; set; }

        public string Ort { get; set; }

        public static KundenViewModel AusEntity(Kunde kunde)
        {
            return new KundenViewModel
            {
                KundeId = kunde.KundeId,
                Firma = kunde.Firma,
                Strasse = kunde.Strasse,
                PLZ = kunde.PLZ,
                Ort = kunde.Ort,
            };
        }
    }
}