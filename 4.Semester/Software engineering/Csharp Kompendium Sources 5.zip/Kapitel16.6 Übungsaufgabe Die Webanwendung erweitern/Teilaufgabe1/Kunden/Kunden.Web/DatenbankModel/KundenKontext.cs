﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kunden.Web.DatenbankModel
{
    public class KundenKontext : DbContext
    {
        public KundenKontext(DbContextOptions<KundenKontext> options)
        : base(options)
        {
        }

        public DbSet<Kunde> Kunden { get; set; }
    }
}