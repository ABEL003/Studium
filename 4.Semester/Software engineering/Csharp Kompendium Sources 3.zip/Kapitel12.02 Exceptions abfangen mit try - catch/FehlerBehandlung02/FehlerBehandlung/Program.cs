﻿using System;

namespace FehlerBehandlung
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie eine ganze Zahl ein:");
            var eingabeZahl1 = Console.ReadLine();

            Console.WriteLine("Geben Sie noch eine ganze Zahl ein:");
            var eingabeZahl2 = Console.ReadLine();

            try
            {
                var zahl1 = int.Parse(eingabeZahl1);
                var zahl2 = int.Parse(eingabeZahl2);

                var zahl3 = zahl1 / 0;

                Console.WriteLine($"{zahl1}+{zahl2}={zahl1 + zahl2}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Sie haben einen Text statt einer ganzen Zahl eingegeben.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unerwarteter Fehler: {ex.Message}");
            }
        }
    }
}