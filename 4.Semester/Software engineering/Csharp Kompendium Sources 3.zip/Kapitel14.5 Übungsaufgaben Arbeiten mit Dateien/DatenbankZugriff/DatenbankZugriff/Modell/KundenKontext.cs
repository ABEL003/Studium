﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DatenbankZugriff.Modell
{
    public class KundenKontext : DbContext
    {
        public DbSet<Kunde> Kunden { get; set; }
        public DbSet<Ansprechpartner> Ansprechpartner
        {
            get;
            set;
        }

        protected override void OnConfiguring
        (DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=Kunden;Trusted_Connection=True;");
        }
    }
}
