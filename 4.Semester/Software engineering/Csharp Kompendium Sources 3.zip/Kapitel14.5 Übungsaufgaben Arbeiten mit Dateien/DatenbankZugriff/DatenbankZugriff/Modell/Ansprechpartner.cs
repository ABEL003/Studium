﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DatenbankZugriff.Modell
{
    [Table("Ansprechpartner")]
    public class Ansprechpartner
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id")]
        public int AnsprechpartnerId { get; set; }

        [ForeignKey("Kunde")]
        [Column("kundenid")]
        public int KundeId { get; set; }

        [Required]
        [MaxLength(50)]
        [Column("vorname")]
        public string Vorname { get; set; }

        [Required]
        [MaxLength(50)]
        [Column("nachname")]
        public string Nachname { get; set; }

        [MaxLength(20)]
        [Column("telefon")]
        public string Telefonnummer { get; set; }

        //Navigation Properties
        public virtual Kunde Kunde { get; set; }
    }
}