﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DatenbankZugriff.Migrations
{
    public partial class AddFremdSchluesselAnsprechPartnerKundeId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Ansprechpartner_KundeId",
                table: "Ansprechpartner",
                column: "KundeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Ansprechpartner_Kunden_KundeId",
                table: "Ansprechpartner",
                column: "KundeId",
                principalTable: "Kunden",
                principalColumn: "KundeId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Ansprechpartner_Kunden_KundeId",
                table: "Ansprechpartner");

            migrationBuilder.DropIndex(
                name: "IX_Ansprechpartner_KundeId",
                table: "Ansprechpartner");
        }
    }
}
