﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DatenbankZugriff.Migrations
{
    public partial class AddKundeId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "KundeId",
                table: "Ansprechpartner",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "KundeId",
                table: "Ansprechpartner");
        }
    }
}
