﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DatenbankZugriff.Migrations
{
    public partial class AddNewMapping : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Ansprechpartner_Kunden_KundeId",
                table: "Ansprechpartner");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Kunden",
                table: "Kunden");

            migrationBuilder.RenameTable(
                name: "Kunden",
                newName: "Kunde");

            migrationBuilder.RenameColumn(
                name: "Vorname",
                table: "Ansprechpartner",
                newName: "vorname");

            migrationBuilder.RenameColumn(
                name: "Nachname",
                table: "Ansprechpartner",
                newName: "nachname");

            migrationBuilder.RenameColumn(
                name: "Telefonnummer",
                table: "Ansprechpartner",
                newName: "telefon");

            migrationBuilder.RenameColumn(
                name: "KundeId",
                table: "Ansprechpartner",
                newName: "kundenid");

            migrationBuilder.RenameColumn(
                name: "AnsprechpartnerId",
                table: "Ansprechpartner",
                newName: "id");

            migrationBuilder.RenameIndex(
                name: "IX_Ansprechpartner_KundeId",
                table: "Ansprechpartner",
                newName: "IX_Ansprechpartner_kundenid");

            migrationBuilder.RenameColumn(
                name: "Strasse",
                table: "Kunde",
                newName: "strasse");

            migrationBuilder.RenameColumn(
                name: "PLZ",
                table: "Kunde",
                newName: "plz");

            migrationBuilder.RenameColumn(
                name: "Ort",
                table: "Kunde",
                newName: "ort");

            migrationBuilder.RenameColumn(
                name: "Firma",
                table: "Kunde",
                newName: "firma");

            migrationBuilder.RenameColumn(
                name: "KundeId",
                table: "Kunde",
                newName: "id");

            migrationBuilder.AlterColumn<string>(
                name: "vorname",
                table: "Ansprechpartner",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "nachname",
                table: "Ansprechpartner",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "telefon",
                table: "Ansprechpartner",
                maxLength: 20,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "strasse",
                table: "Kunde",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "plz",
                table: "Kunde",
                maxLength: 5,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ort",
                table: "Kunde",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "firma",
                table: "Kunde",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Kunde",
                table: "Kunde",
                column: "id");

            migrationBuilder.AddForeignKey(
                name: "FK_Ansprechpartner_Kunde_kundenid",
                table: "Ansprechpartner",
                column: "kundenid",
                principalTable: "Kunde",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Ansprechpartner_Kunde_kundenid",
                table: "Ansprechpartner");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Kunde",
                table: "Kunde");

            migrationBuilder.RenameTable(
                name: "Kunde",
                newName: "Kunden");

            migrationBuilder.RenameColumn(
                name: "vorname",
                table: "Ansprechpartner",
                newName: "Vorname");

            migrationBuilder.RenameColumn(
                name: "nachname",
                table: "Ansprechpartner",
                newName: "Nachname");

            migrationBuilder.RenameColumn(
                name: "telefon",
                table: "Ansprechpartner",
                newName: "Telefonnummer");

            migrationBuilder.RenameColumn(
                name: "kundenid",
                table: "Ansprechpartner",
                newName: "KundeId");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "Ansprechpartner",
                newName: "AnsprechpartnerId");

            migrationBuilder.RenameIndex(
                name: "IX_Ansprechpartner_kundenid",
                table: "Ansprechpartner",
                newName: "IX_Ansprechpartner_KundeId");

            migrationBuilder.RenameColumn(
                name: "strasse",
                table: "Kunden",
                newName: "Strasse");

            migrationBuilder.RenameColumn(
                name: "plz",
                table: "Kunden",
                newName: "PLZ");

            migrationBuilder.RenameColumn(
                name: "ort",
                table: "Kunden",
                newName: "Ort");

            migrationBuilder.RenameColumn(
                name: "firma",
                table: "Kunden",
                newName: "Firma");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "Kunden",
                newName: "KundeId");

            migrationBuilder.AlterColumn<string>(
                name: "Vorname",
                table: "Ansprechpartner",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldMaxLength: 50);

            migrationBuilder.AlterColumn<string>(
                name: "Nachname",
                table: "Ansprechpartner",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldMaxLength: 50);

            migrationBuilder.AlterColumn<string>(
                name: "Telefonnummer",
                table: "Ansprechpartner",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldMaxLength: 20,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Strasse",
                table: "Kunden",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "PLZ",
                table: "Kunden",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldMaxLength: 5,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Ort",
                table: "Kunden",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Firma",
                table: "Kunden",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldMaxLength: 50);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Kunden",
                table: "Kunden",
                column: "KundeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Ansprechpartner_Kunden_KundeId",
                table: "Ansprechpartner",
                column: "KundeId",
                principalTable: "Kunden",
                principalColumn: "KundeId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
