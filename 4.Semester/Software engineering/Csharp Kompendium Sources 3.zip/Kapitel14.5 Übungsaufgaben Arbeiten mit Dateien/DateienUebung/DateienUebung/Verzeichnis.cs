﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace DateienUebung
{
    [XmlType("verzeichnis")]
    public class Verzeichnis : Datei
    {
        public Verzeichnis()
        {
            Dateien = new List<Datei>();
            Verzeichnisse = new List<Verzeichnis>();
        }

        [XmlArray("dateien")]
        public List<Datei> Dateien { get; set; }

        [XmlArray("verzeichnisse")]
        public List<Verzeichnis> Verzeichnisse { get; set; }

        public static Verzeichnis Lade(string verzeichnisName)
        {
            var verzeichnisInfo = new DirectoryInfo(verzeichnisName);
            var verzeichnis = new Verzeichnis();

            if (verzeichnisInfo.Exists)
            {
                verzeichnis = LeseVerzeichnisRekursiv(verzeichnisInfo);
            }

            return verzeichnis;
        }

        private static Verzeichnis LeseVerzeichnisRekursiv(DirectoryInfo verzeichnisInfo)
        {
            var verzeichnis = new Verzeichnis();
            verzeichnis.Name = verzeichnisInfo.Name;
            verzeichnis.ErstellungsDatum = verzeichnisInfo.CreationTime;

            foreach (var dateiInfo in verzeichnisInfo.GetFiles())
            {
                var datei = new Datei();
                datei.Name = dateiInfo.Name;
                datei.ErstellungsDatum = dateiInfo.CreationTime;

                verzeichnis.Dateien.Add(datei);
            }

            foreach (var unterverzeichnisInfo in verzeichnisInfo.
            GetDirectories())
            {
                var unterVerzeichnis = LeseVerzeichnisRekursiv(unterverzeichnisInfo);
                verzeichnis.Verzeichnisse.Add(unterVerzeichnis);
            }

            return verzeichnis;
        }

        public void Ausgabe()
        {
            AusgabeRekursiv(this, "");
        }

        private void AusgabeRekursiv(Verzeichnis verzeichnis, string
        einrueckung)
        {
            Console.WriteLine($"{einrueckung}<Verzeichnis> {verzeichnis.Name}({ verzeichnis.ErstellungsDatum})");

            einrueckung += " ";

            foreach (var datei in verzeichnis.Dateien)
            {
                Console.WriteLine($"{einrueckung}{datei.Name} ({datei.ErstellungsDatum})");
            }

            foreach (var unterverzeichnis in verzeichnis.Verzeichnisse)
            {
                AusgabeRekursiv(unterverzeichnis, einrueckung);
            }
        }

        public void AusgabeInDatei(string dateiName)
        {
            var Serialisierer = new XmlSerializer(typeof(Verzeichnis));
            using (var fileStream = new FileStream(dateiName, FileMode.
            Create))
            {
                Serialisierer.Serialize(fileStream, this);
            }
        }
    }
}
