﻿using System;

namespace DateienUebung
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 1 || args.Length > 2)
            {
                return;
            }

            var verzeichnis = Verzeichnis.Lade(args[0]);
            verzeichnis.Ausgabe();

            if (args.Length == 2)
            {
                verzeichnis.AusgabeInDatei(args[1]);
            }
        }
    }
}