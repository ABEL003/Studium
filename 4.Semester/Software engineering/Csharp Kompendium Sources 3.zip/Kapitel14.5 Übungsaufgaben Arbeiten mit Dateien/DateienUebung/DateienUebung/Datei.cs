﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace DateienUebung
{
    [XmlType("datei")]
    public class Datei
    {
        [XmlAttribute("name")]
        public string Name { get; set; }
        [XmlAttribute("erstellungsdatum")]
        public DateTime ErstellungsDatum { get; set; }
    }
}