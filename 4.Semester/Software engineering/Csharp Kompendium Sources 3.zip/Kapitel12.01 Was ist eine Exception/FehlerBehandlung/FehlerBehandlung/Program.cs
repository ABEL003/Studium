﻿using System;

namespace FehlerBehandlung
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie eine ganze Zahl ein:");
            var eingabeZahl1 = Console.ReadLine();

            Console.WriteLine("Geben Sie noch eine ganze Zahl ein: ");
            var eingabeZahl2 = Console.ReadLine();

            var zahl1 = int.Parse(eingabeZahl1);
            var zahl2 = int.Parse(eingabeZahl2);

            Console.WriteLine($"{zahl1}+{zahl2}={zahl1 + zahl2}");
        }
    }
}