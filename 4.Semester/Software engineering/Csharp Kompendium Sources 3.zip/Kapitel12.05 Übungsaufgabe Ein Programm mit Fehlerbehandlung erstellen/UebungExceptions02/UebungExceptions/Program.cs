﻿using System;

namespace UebungExcpetions
{
    class Program
    {
        static bool fertig;
        static void Main(string[] args)
        {
        }

        static int LeseZahlEin()
        {
            Console.WriteLine("Geben Sie eine ganze Zahl ein:");
            var eingabeZahl = Console.ReadLine();
            if (eingabeZahl == "fertig")
            {
                fertig = true;
                return 0;
            }

            if (int.TryParse(eingabeZahl, out int zahl) ==
            false)
            {
                throw new EingabeFehlerException($"{eingabeZahl} ist keine ganze Zahl.");
            }

            return zahl;
        }
    }
}