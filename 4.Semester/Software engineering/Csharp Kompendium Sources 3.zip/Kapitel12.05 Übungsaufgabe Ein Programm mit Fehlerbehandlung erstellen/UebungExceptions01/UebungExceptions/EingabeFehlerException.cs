﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace UebungExcpetions
{
    public class EingabeFehlerException : Exception
    {
        public EingabeFehlerException() : base()
        {
        }

        public EingabeFehlerException(string message) : base(message)
        {
        }

        public EingabeFehlerException(string message, Exception inner) : base(message, inner)
        {
        }

        public EingabeFehlerException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}