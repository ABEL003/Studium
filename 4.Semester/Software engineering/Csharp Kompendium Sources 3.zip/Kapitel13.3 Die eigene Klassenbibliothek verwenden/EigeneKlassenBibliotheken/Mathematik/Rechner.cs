﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MeineFirma.Mathematik
{
    public class Rechner
    {
        public double Addiere(double a, double b)
        {
            return a + b;
        }

        public double Subtrahiere(double a, double b)
        {
            return a - b;
        }

        public double Mulitpliziere(double a, double b)
        {
            return a * b;
        }

        public double Dividiere(double a, double b)
        {
            return a / b;
        }

    }
}