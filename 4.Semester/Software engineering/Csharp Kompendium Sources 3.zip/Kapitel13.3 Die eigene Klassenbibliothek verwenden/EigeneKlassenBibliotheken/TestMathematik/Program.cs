﻿using System;
using MeineFirma.Mathematik;

namespace TestMathematik
{
    class Program
    {
        static void Main(string[] args)
        {
            var rechner = new Rechner();
            var a = 5.0d;
            var b = 4.0d;
            var c = rechner.Addiere(a, b);
            Console.WriteLine($"{a} + {b} = {c}");
        }
    }
}