﻿using MeineFirma.Mathematik;
using System;

namespace TestMathematik2
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = 6;
            var b = 7;
            var rechner = new Rechner();
            var c = rechner.Mulitpliziere(a, b);
            Console.WriteLine($"{a} * {b} = {c}");
        }
    }
}