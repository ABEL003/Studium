﻿using System;
using System.IO;

namespace KonfigurationsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var text = "Benutzer = Max Mustermann\r\nSchuhGröße=46\r\n";
            File.WriteAllText("Konfiguration.txt", text);
        }
    }
}