﻿using System;
using System.IO;

namespace KonfigurationsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] text =
            {
                "Benutzer = Peter Müller",
                "SchuhGröße=45"
            };

            File.WriteAllLines("Konfiguration.txt", text);
        }
    }
}