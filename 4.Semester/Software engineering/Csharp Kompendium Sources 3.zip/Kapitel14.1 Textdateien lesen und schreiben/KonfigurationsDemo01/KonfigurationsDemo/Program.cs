﻿using System;
using System.IO;

namespace KonfigurationsDemo
{
    class Program

    {
        static void Main(string[] args)
        {
            string text = File.ReadAllText("Konfiguration.txt");
            Console.WriteLine(text);
        }
    }
}