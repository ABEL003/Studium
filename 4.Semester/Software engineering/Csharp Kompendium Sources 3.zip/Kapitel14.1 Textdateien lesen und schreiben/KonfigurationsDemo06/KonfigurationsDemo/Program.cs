﻿using System;
using System.IO;

namespace KonfigurationsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] text =
            {
                "Benutzer = Marta Musterfrau",
                "SchuhGröße=37"
            };

            var dateiInfo = new FileInfo("Konfiguration.txt");
            using (FileStream dateiStrom = dateiInfo.OpenWrite())
            {
                using (StreamWriter schreiber = new
                StreamWriter(dateiStrom))
                {
                    foreach (var zeile in text)
                    {
                        schreiber.WriteLine(zeile);
                    }
                    schreiber.Flush();
                    schreiber.Close();
                }
            }
        }
    }
}