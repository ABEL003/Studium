﻿using System;
using System.IO;

namespace KonfigurationsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] zeilen = File.ReadAllLines("Konfiguration.txt");

            foreach (var zeile in zeilen)
            {
                var zeilenElemente = zeile.Split("=");

                if (zeilenElemente.Length != 2)
                {
                    continue;
                }
                var variable = zeilenElemente[0].Trim();
                var wert = zeilenElemente[1].Trim();
                Console.WriteLine($"Die Varibale ‚{variable}‘ hat den Inhalt ‚{ wert}‘");
            }
        }
    }
}