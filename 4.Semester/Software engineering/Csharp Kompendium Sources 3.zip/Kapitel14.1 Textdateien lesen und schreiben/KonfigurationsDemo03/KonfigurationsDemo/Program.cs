﻿using System;
using System.IO;

namespace KonfigurationsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var dateiInfo = new FileInfo("Konfiguration.txt");
            using (StreamReader leser = dateiInfo.OpenText())
            {
                while (!leser.EndOfStream)
                {
                    var zeile = leser.ReadLine();
                    Console.WriteLine(zeile);
                }
            }
        }
    }
}