﻿using System;
using System.IO;

namespace LogDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string logDatei = "Log.txt";
            File.AppendAllText(logDatei, "1. Logeintrag\r\n");
            File.AppendAllText(logDatei, "2. Logeintrag\r\n");
            File.AppendAllText(logDatei, "3. Logeintrag\r\n");
        }
    }
}
