﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace XMLVerarbeitung
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement wurzel = new XElement("Personen",
                new XElement("Person",
                    new XAttribute("Id", "1"),
                    new XElement("Vorname", "Robert"),
                    new XElement("Nachname", "Schiefele")),
                new XElement("Person",
                    new XAttribute("Id", "2"),
                    new XElement("Vorname", "Max"),
                    new XElement("Nachname", "Mustermann")),
                new XElement("Person",
                    new XAttribute("Id", "3"),
                    new XElement("Vorname", "Marta"),
                    new XElement("Nachname", "Musterfrau")));

            wurzel.Save("Personen.xml");
        }
    }
}
