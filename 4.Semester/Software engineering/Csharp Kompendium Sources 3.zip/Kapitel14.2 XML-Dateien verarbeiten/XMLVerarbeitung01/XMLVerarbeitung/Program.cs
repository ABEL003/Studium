﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace XMLVerarbeitung
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement wurzel = XElement.Load("Personen.xml");
            IEnumerable<XElement> xmlPersonen = wurzel.
            Descendants("Person");

            foreach (XElement xmlPerson in xmlPersonen)
            {
                var id = xmlPerson.Attribute("Id").Value;
                var vorname = xmlPerson.Descendants("Vorname").First().Value;
                var nachname = xmlPerson.Descendants("Nachname").First().Value;
                Console.WriteLine($"Id {id}; Vorname: {vorname}; Nachname: {nachname}");
            }
        }
    }
}