﻿using System;
using System.IO;
using System.Linq;

namespace Verzeichnisse
{
    class Program
    {
        static void Main(string[] args)
        {
            var verzeichnisInfo = new DirectoryInfo("C:\\Windows");
           
            var dateien = verzeichnisInfo.GetFiles();

            foreach (var datei in dateien.Where(v => v.Extension == ".exe"))
            {
                Console.WriteLine(datei.FullName);
            }
        }
    }
}