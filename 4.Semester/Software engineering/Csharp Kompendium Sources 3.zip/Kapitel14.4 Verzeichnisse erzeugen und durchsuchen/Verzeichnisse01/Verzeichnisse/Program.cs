﻿using System;
using System.IO;

namespace Verzeichnisse
{
    class Program
    {
        static void Main(string[] args)
        {
            var verzeichnisInfo = new
            DirectoryInfo("NeuesVerzeichnis");
            if (!verzeichnisInfo.Exists)
            {
                verzeichnisInfo.Create();
                verzeichnisInfo.Refresh();
            }

            Console.WriteLine(verzeichnisInfo.FullName);
            Console.WriteLine(verzeichnisInfo.CreationTime);
        }
    }
}