﻿using System;
using System.IO;
using System.Linq;

namespace Verzeichnisse
{
    class Program
    {
        static void Main(string[] args)
        {
            var verzeichnisInfo = new DirectoryInfo("C:\\Windows");
            var verzeichnisse = verzeichnisInfo.GetDirectories();

            foreach (var verzeichnis in verzeichnisse.Where(v => v.Name.StartsWith("a")))
            {
                Console.WriteLine(verzeichnis.FullName);
            }
        }
    }
}
