﻿using System;

namespace DebuggerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = 3;
            for (var i = 1; i < 5; i++)
            {
                var b = a / (a - i);
            }
        }
    }
}