﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace FehlerBehandlung
{
    public class FalscheEingabeException : Exception
    {
        public FalscheEingabeException() : base("Es wurde eine falsche Eingabe gemacht.")
        {
        }

        public FalscheEingabeException(string message) : base(message)
        {
        }

        public FalscheEingabeException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public FalscheEingabeException(SerializationInfo info,
        StreamingContext context) : base(info, context)
        {
        }
    }
}