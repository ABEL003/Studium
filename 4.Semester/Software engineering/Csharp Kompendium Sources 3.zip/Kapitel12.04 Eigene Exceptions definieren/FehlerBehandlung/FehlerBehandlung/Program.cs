﻿using System;

namespace FehlerBehandlung
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Start();
            }
            catch (FalscheEingabeException ex)
            {
                if (ex.InnerException == null)
                {
                    Console.WriteLine(ex.Message);
                }
                else
                {
                    Console.WriteLine($"{ ex.Message} {ex.InnerException.Message}");
                }
            }
        }

        static void Start()
        {
            Console.WriteLine("Geben Sie eine ganze Zahl ein:");
            var eingabeZahl1 = Console.ReadLine();

            if (eingabeZahl1 == "")
            {
                throw new FalscheEingabeException("Sie müssen eine ganze Zahl eingeben.");
            }

            if (int.TryParse(eingabeZahl1, out int zahl1) == false)
            {
                throw new FalscheEingabeException($"{eingabeZahl1} ist keine ganze Zahl.");
            }

            Console.WriteLine("Geben Sie noch eine ganze Zahl ein: ");
            var eingabeZahl2 = Console.ReadLine();

            if (eingabeZahl2 == "")
            {
                throw new FalscheEingabeException("Sie müssen noch eine ganze Zahl eingeben.");
            }

            if (int.TryParse(eingabeZahl2, out int zahl2) ==
            false)
            {
                throw new FalscheEingabeException($"{eingabeZahl2} ist keine ganze Zahl.");
            }

            try
            {
                var zahl3 = zahl1 / 0;
                Console.WriteLine($"{zahl1}+{zahl2}={zahl1 + zahl2}");
            }
            catch (Exception ex)
            {
                throw new FalscheEingabeException("Unbekannter Fehler: ", ex);
            }
        }
    }
}