﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using System.Xml.Serialization;

namespace XMLVerarbeitung
{
    [XmlType("person")]
    public class Person
    {
        [XmlAttribute("id")]
        public int Id { get; set; }

        [XmlElement("vorname")]
        public string Vorname { get; set; }

        [XmlElement("nachname")]
        public string Nachname { get; set; }

        public static List<Person> Personen
        {
            get
            {
                return new List<Person>
                {
                    new Person
                    {
                        Id =1,
                        Vorname = "Robert",
                        Nachname = "Schiefele",
                    },
                    new Person
                    {
                        Id = 2,
                        Vorname = "Max",
                        Nachname = "Mustermann",
                    },
                    new Person
                    {
                        Id = 3,
                        Vorname = "Marta",
                        Nachname = "Musterfrau",
                    }
                };
            }
        }
    }
}