﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace XMLVerarbeitung
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> personen = null;
            var rootAttribute = new XmlRootAttribute
            {
                ElementName = "personen"
            };
            var seralisierer = new XmlSerializer(typeof(List<Person>), rootAttribute);
            using (var fileStream = new FileStream("Personen.xml", FileMode.Open))
            {
                personen = (List<Person>)seralisierer.Deserialize(fileStream);
            }

            foreach (var person in personen)
            {
                Console.WriteLine($"Id: {person.Id}; Vorname: {person.Vorname}; Nachname: { person.Nachname}; ");
            }
        }
    }
}