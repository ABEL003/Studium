﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace XMLVerarbeitung
{
    class Program
    {
        static void Main(string[] args)
        {
            var seralisierer = new XmlSerializer(typeof(List<Person>));

            using (var fileStream = new FileStream("Personen.xml", FileMode.Create))
            {
                seralisierer.Serialize(fileStream, Person.Personen);
            }
        }
    }
}
