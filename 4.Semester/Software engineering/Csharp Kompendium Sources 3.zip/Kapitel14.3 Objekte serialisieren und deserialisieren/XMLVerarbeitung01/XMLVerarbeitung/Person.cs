﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XMLVerarbeitung
{
    public class Person
    {
        public int Id { get; set; }
        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public static List<Person> Personen
        {
            get
            {
                return new List<Person>
                {
                    new Person
                    {
                        Id =1,
                        Vorname = "Robert",
                        Nachname = "Schiefele",
                    },
                    new Person
                    {
                        Id = 2,
                        Vorname = "Max",
                        Nachname = "Mustermann",
                    },
                    new Person
                    {
                        Id = 3,
                        Vorname = "Marta",
                        Nachname = "Musterfrau",
                    }
                };
            }
        }
    }
}
