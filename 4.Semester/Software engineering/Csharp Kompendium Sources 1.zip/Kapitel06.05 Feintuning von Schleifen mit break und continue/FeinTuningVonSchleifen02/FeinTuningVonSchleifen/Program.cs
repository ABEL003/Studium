﻿using System;

namespace FeinTuningVonSchleifen
{
    class Program
    {
        static void Main(string[] args)
        {
            var text = @"Das Buch C# Das Kompendium ist ein Buch
            zum Erlernen von C#. Geschrieben hat
            das Buch Robert Schiefele.";

            var suchbegriff = "Buch";

            var wortGefunden = false;
            var wortIstInZeile = 0;
            var wortIstAnPosition = 0;
            var zeilen = text.Split("\r\n");

            for (var i = 0; i < zeilen.Length; i++)
            {
                var woerter = zeilen[i].Split(" ");
                for (var j = 0; j < woerter.Length; j++)
                {
                    if (wortGefunden == false)
                    {
                        if (woerter[j] == suchbegriff)
                        {
                            wortIstInZeile = i + 1;
                            wortIstAnPosition = j + 1;
                            wortGefunden = true;
                            break;
                        }
                    }
                }
                if (wortGefunden == true)
                    break;
            }

            Console.WriteLine($"Das Wort {suchbegriff} befindet sich in Zeile: { wortIstInZeile} an Position: {wortIstAnPosition}");
        }
    }
}