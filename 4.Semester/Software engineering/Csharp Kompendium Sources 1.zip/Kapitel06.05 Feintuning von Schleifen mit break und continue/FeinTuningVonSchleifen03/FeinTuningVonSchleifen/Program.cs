﻿using System;

namespace FeinTuningVonSchleifen
{
    class Program
    {
        static void Main(string[] args)
        {
            var text = @"Die Woche hat sieben Tage.
             Die Tage der Woche heißen:
             Montag
             Dienstag
             Mittwoch
             Donnerstag
             Freitag
             Samstag
             und Sonntag.";

            var anzahlWorter = 0;

            var zeilen = text.Split("\r\n");
            foreach (var zeile in zeilen)
            {
                var woerter = zeile.Split("");
                foreach (var wort in woerter)
                {
                    anzahlWorter++;
                }
            }

            Console.WriteLine($"Der Text besteht aus { anzahlWorter} Wörtern.");
        }
    }
}

