﻿using System;
using System.Threading;

namespace ZeitMessung
{
    class Program
    {
        static void Main(string[] args)
        {
            long start = DateTime.Now.Ticks;
            Thread.Sleep(1000);
            long ende = DateTime.Now.Ticks;
            TimeSpan dauer = TimeSpan.FromTicks(ende - start);
            Console.WriteLine($"Programmausführungszeit: {dauer.TotalMilliseconds}");
        }
    }
}