﻿using System;

namespace Variablen
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "Programmieren lernen mit \r\n\"Hello World\"";
            Console.WriteLine(text);
        }
    }
}
