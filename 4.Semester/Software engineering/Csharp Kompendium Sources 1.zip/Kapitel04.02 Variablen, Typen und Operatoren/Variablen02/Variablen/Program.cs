﻿using System;

namespace Variablen
{
    class Program
    {
        static void Main(string[] args)
        {
            double a = 69.82d;
            double b = 69.2d + 0.62d;
            Console.WriteLine(a - b);
        }
    }
}
