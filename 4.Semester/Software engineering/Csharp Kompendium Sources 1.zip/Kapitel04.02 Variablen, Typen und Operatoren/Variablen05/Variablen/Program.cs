﻿using System;

namespace Variablen
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            int b = 2;
            int c = a + b;
            string ausgabe = $"{a} + {b} = {c}";
            Console.WriteLine(ausgabe);
        }
    }
}
