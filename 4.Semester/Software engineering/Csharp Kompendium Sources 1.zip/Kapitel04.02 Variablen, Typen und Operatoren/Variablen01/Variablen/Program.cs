﻿using System;

namespace Variablen
{
    class Program
    {
        static void Main(string[] args)
        {
            float x = 0.123456789f;
            Console.WriteLine(x);
        }
    }
}
