﻿using System;

namespace Variablen
{
    class Program
    {
        static void Main(string[] args)
        {
            float a = 69.82f;
            float b = 69.2f + 0.62f;
            Console.WriteLine(a - b);
        }
    }
}
