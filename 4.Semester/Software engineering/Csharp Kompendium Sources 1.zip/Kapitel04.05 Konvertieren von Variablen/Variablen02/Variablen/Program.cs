﻿using System;

namespace Variablen
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = int.Parse("4");
            var b = int.Parse("2");
            var ausgabe = a + b;
            Console.WriteLine(ausgabe);
        }
    }
}
