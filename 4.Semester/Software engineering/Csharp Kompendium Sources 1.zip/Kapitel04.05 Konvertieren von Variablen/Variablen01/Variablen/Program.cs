﻿using System;

namespace Variablen
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = "4"; // Die Zahl 4 als string
            var b = "2"; // Die Zahl 2 als string
            var ausgabe = a + b; //Mal sehen was da gerechnet wird
            Console.WriteLine(ausgabe);
        }
    }
}
