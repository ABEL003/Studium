﻿using System;

namespace KonsolenApp
{
    class Program
    {
        static void Main(string[] args)
        {
            KonsolenApp.InSpanisch().Start();
        }
    }
}
