﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonsolenApp
{
    class KonsolenApp
    {
        public string Begruessung = "Hallo Welt!";

        public static KonsolenApp InSpanisch()
        {
            var instanz = new KonsolenApp("Hola Mundo!");
            return instanz;
        }

        public KonsolenApp()
        {

        }

        public KonsolenApp(string begruessung)
        {
            this.Begruessung = begruessung;
        }

        public void Start()
        {
            Console.WriteLine(Begruessung);
        }
    }
}