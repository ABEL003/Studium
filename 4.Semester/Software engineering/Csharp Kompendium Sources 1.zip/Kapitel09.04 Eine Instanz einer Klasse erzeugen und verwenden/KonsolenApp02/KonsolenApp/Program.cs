﻿using System;

namespace KonsolenApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var konsole = new KonsolenApp("Hello World");
            konsole.Start();
        }
    }
}
