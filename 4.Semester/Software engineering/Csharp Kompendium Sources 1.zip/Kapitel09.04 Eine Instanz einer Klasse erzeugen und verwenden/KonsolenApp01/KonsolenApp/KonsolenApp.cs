﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonsolenApp
{
    class KonsolenApp
    {
        public string Begruessung = "Hallo Welt!";

        public KonsolenApp()
        {

        }

        public KonsolenApp(string begruessung)
        {
        }

        public void Start()
        {
            Console.WriteLine(Begruessung);
        }
    }
}