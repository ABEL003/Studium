﻿using System;

namespace BenutzerUndPasswort
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie Ihren Benutzernamen:");
            var benutzer = Console.ReadLine();
            Console.WriteLine("Geben Sie Ihr Passwort ein:");
            var passwort = Console.ReadLine();
            if (benutzer == "Robert")
            {
                if (passwort == "1234")
                    Console.WriteLine("Zugriff autorisiert!");
                else
                    Console.WriteLine("Zugriff verweigert!");
            }
            else
            {
                Console.WriteLine("Benutzer unbekannt!");
            }
        }
    }
}