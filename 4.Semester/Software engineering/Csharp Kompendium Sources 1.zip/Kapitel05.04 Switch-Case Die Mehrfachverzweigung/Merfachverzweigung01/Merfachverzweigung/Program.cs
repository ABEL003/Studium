﻿using System;

namespace Mehrfachverzweigung
{
 class Program
    {
        enum Wochentag
        {
            Montag = 1,
            Dienstag = 2,
            Mittwoch = 3,
            Donnerstag = 4,
            Freitag = 5,
            Samstag = 6,
            Sonntag = 7
        }

        static void Main(string[] args)
        {
            Wochentag wochentag = Wochentag.Montag;
            Console.WriteLine(wochentag);
        }
    }
}