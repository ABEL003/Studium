﻿using System;

namespace MehrfachverzweigungKurzform
{
    class Program
    {
        enum Land
        {
            Deutschland,
            Oesterreich,
            Schweiz,
            Spanien,
            Italien,
            USA,
            England
        }

        static void Main(string[] args)
        {
            var land = Land.Italien;

            switch (land)
            {
                case Land.Deutschland:
                case Land.Oesterreich:
                case Land.Schweiz:
                    Console.WriteLine("Hallo Welt!");
                    break;
                case Land.USA:
                case Land.England:
                    Console.WriteLine("Hello World!");
                    break;
                case Land.Spanien:
                    Console.WriteLine("Hola Mundo!");
                    break;
                case Land.Italien:
                    Console.WriteLine("Ciao Mondo!");
                    break;
            }
        }

    }
}