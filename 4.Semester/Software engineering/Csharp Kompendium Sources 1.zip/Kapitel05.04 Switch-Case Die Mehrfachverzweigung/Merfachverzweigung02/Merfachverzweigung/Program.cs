﻿using System;

namespace Mehrfachverzweigung
{
    class Program
    {
        enum Wochentag
        {
            Montag = 1,
            Dienstag = 2,
            Mittwoch = 3,
            Donnerstag = 4,
            Freitag = 5,
            Samstag = 6,
            Sonntag = 7
        }

        static void Main(string[] args)
        {
            Wochentag wochentag = Wochentag.Montag;
            string ausgabe;

            switch (wochentag)
            {
                case Wochentag.Montag:
                    ausgabe = "Oh nein! Die Arbeitswoche hat begonnen.";
                    break;
                case Wochentag.Dienstag:
                    ausgabe = "Oje! Die Woche ist noch nicht mal halb vorbei.";
                    break;

                case Wochentag.Mittwoch:
                    ausgabe = "Na endlich! Die halbe Woche schon vorbei.";
                    break;
                case Wochentag.Donnerstag:
                    ausgabe = "Wahnsinn! Die Woche ist fast vorbei.";
                    break;
                case Wochentag.Freitag:
                    ausgabe = "Yeaaah! Der letzte Arbeitstag der Woche.";
                    break;
                case Wochentag.Samstag:
                    ausgabe = "Hurra! Endlich Wochenende.";
                    break;
                default:
                    ausgabe = "Erst mal chillen!";
                    break;
            }

            Console.WriteLine(ausgabe);
        }
    }
}
