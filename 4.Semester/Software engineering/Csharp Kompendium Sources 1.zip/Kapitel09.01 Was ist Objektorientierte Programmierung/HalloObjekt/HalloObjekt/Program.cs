﻿using System;

namespace HalloObjekt
{
    class Program
    {
        static void Main(string[] args)
        {
            var meinProgramm = new Program();
            meinProgramm.Hallo();
        }

        void Hallo()
        {
            Console.WriteLine("Hello Objektorientierung!");
        }
    }
}