﻿using System;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] wochentage = { "Montag", "Dienstag","Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"};
            for (var i = 0; i < wochentage.Length; i++)
            {
                Console.WriteLine(wochentage[i]);
            }
        }
    }
}