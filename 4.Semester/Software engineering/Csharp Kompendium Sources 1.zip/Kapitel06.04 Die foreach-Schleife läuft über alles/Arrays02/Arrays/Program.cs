﻿using System;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] wochentage = { "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"};
            foreach (var wochentag in wochentage)
            {
                Console.WriteLine(wochentag);
            }

        }
    }
}