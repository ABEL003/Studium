﻿using System;

namespace ForeachSchleife
{
    class Program
    {
        static void Main(string[] args)
        {
            var wochentage = new string[] { "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag" };

            for (var i = 0; i < wochentage.Length; i++)
            {
                wochentage[i] = $"{i + 1} {wochentage[i]}";
                Console.WriteLine(wochentage[i]);
            }
        }
    }
}
