﻿using System;

namespace ForeachSchleife
{
    class Program
    {
        static void Main(string[] args)
        {
            var wochentage = new string[] { "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag" };
            var i = 0;
            foreach (var wochentag in wochentage)
            {
                i++;
                wochentag = $"{i} {wochentag}";
                Console.WriteLine(wochentag);
            }
        }
    }
}