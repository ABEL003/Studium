﻿using System;

namespace Uebung_6_6_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ein Array mit Zahlen von 1-9
            int[] zahlen = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            //Schleife läuft über das gesamte Array
            foreach (var zahl in zahlen)
            {
                //Die Schleife hat „zahl“ Durchgänge
                for (var i = 0; i < zahl; i++)
                {
                    Console.Write("*");
                }

                //Ein Zeilenumbruch am Ende von jedem Durchgang
                //der äußeren Schleife
                Console.WriteLine();
            }
        }
    }
}

