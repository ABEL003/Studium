﻿using System;

namespace Uebung_6_6_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Hier speichern wir den vollständigen
            //eingegebenen Text
            var text = "";
            //Das Fertig-Kommando legen wir uns auch in eine
            //Variable, damit wir es nur an einer Stelle
            //ändern müssen falls nötig
            var fertig = "Fertig!";
            //Hier speichern wir die aktuelle eingegebene
            //Zeile
            var eingabe = "";

            //Die Schleife läuft, bis der Benutzer
            //das Fertig-Kommando eingibt
            while ((eingabe = Console.ReadLine()) != fertig)
            {
                //Die neue Zeile an den Text anhängen
                text += eingabe;

                //Einen Zeilenumbruch an den Text anhängen 
                text += "\r\n";
            }

            Console.WriteLine("**********");

            //Text in Zeilen splitten
            var zeilen = text.Split("\r\n");

            //Die Schleife läuft über alle Zeilen
            foreach (var zeile in zeilen)
            {
                //Wenn wir die Zeile mit dem Fertig-Kommando
                //noch nicht erreicht haben
                if (zeile != fertig)
                {
                    //dann geben wir die Zeile aus
                    Console.WriteLine(zeile);
                }
            }
        }
    }
}
