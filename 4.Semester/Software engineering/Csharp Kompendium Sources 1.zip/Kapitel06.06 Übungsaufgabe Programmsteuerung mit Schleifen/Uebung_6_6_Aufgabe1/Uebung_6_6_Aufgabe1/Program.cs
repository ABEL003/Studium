﻿using System;

namespace Uebung_6_6_Aufgabe1
{
    class Program
    {
        static void Main(string[] args)
        {
            int zahl = 0;
            Console.WriteLine("Geben Sie eine ganze Zahl ein:");
            do
            {
                Console.WriteLine($"5 geteilt durch {zahl} = {(5 / zahl)} Rest { 5 % zahl} ");

                Console.WriteLine("Geben Sie eine ganze Zahl ein: ");
            }
            while ((zahl = int.Parse(Console.ReadLine())) != 0);
            Console.WriteLine("Durch 0 kann nicht geteilt werden!");
        }
    }
}
