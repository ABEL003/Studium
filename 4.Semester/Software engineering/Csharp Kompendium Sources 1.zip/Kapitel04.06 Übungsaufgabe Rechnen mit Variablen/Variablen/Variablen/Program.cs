﻿using System;

namespace Variablen
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie eine ganze Zahl ein:");
            var a = Console.ReadLine();
            Console.WriteLine("Geben Sie noch eine ganze Zahl ein:");
            var b = Console.ReadLine();
            var ausgabe = int.Parse(a) + int.Parse(b);
            Console.WriteLine($"Die Summe von {a} und {b} ist {ausgabe}.");
        }
    }
}