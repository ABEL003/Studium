﻿using System;
using System.Collections.Generic;

namespace TicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            var leeresFeld = "#";
            var kreuz = "X";
            var kreis = "O";

            string spieler1, spieler2;

            var spielFeld = new string[4, 4]
            {
                {" ","1", "2", "3"},
                { "A",leeresFeld, leeresFeld, leeresFeld},
                { "B",leeresFeld, leeresFeld, leeresFeld},
                { "C",leeresFeld, leeresFeld, leeresFeld}
            };

            spieler1 = FrageSpielerNameAb(1);
            spieler2 = FrageSpielerNameAb(2);

        }

        static string FrageSpielerNameAb(int spielerNummer)
        {
            Console.WriteLine($"Geben Sie einen Namen für Spieler {spielerNummer} ein: ");
            return Console.ReadLine();
        }

        static void Spielzug(string name, string spielstein,
        string[,] spielFeld, string leeresFeld)
        {

            var eingabeOk = false;
            List<string> buchstaben = new List<string> { "A", "B", "C" };
            List<string> zahlen = new List<string> { "1", "2", "3" };
            string fehler = "Ungültiger Zug!";
            string feldBesetzt = "Dieses Feld ist schon besetzt!";

            while (!eingabeOk)
            {
                Console.WriteLine($"{name}, geben Sie die Koordinaten für Ihren Zug ein(Buchstabe, Zahl)");

                var eingabe = Console.ReadLine();

                if (eingabe.Length != 3)
                {
                    Console.WriteLine(fehler);
                    continue;
                }

                var koordinaten = eingabe.Split(",");

                if (koordinaten.Length != 2)
                {
                    Console.WriteLine(fehler);
                }

                if (!buchstaben.Contains(koordinaten[0]))
                {
                    Console.WriteLine(fehler);
                    continue;
                }

                if (!zahlen.Contains(koordinaten[1]))
                {
                    Console.WriteLine(fehler);
                    continue;
                }

                var i = buchstaben.IndexOf(koordinaten[0]) + 1;
                var j = int.Parse(koordinaten[1]);

                if (spielFeld[i, j] != leeresFeld)
                {
                    Console.WriteLine(feldBesetzt);
                    continue;
                }

                spielFeld[i, j] = spielstein;

                eingabeOk = true;
            }
        }

        static void ZeigeSpielFeld(string[,] spielFeld)
        {
            for (var i = 0; i < 4; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    Console.Write(spielFeld[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
