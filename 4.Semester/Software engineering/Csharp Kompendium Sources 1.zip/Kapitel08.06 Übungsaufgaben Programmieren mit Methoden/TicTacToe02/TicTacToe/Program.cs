﻿using System;

namespace TicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            var leeresFeld = "#";
            var kreuz = "X";
            var kreis = "O";

            string spieler1, spieler2;

            var spielFeld = new string[4, 4]
            {
                {" ","1", "2", "3"},
                { "A",leeresFeld, leeresFeld, leeresFeld},
                { "B",leeresFeld, leeresFeld, leeresFeld},
                { "C",leeresFeld, leeresFeld, leeresFeld}
            };

            spieler1 = FrageSpielerNameAb(1);
            spieler2 = FrageSpielerNameAb(2);
        }

        static string FrageSpielerNameAb(int spielerNummer)
        {
            Console.WriteLine($"Geben Sie einen Namen für Spieler { spielerNummer} ein: ");
            return Console.ReadLine();
        }

    }
}
