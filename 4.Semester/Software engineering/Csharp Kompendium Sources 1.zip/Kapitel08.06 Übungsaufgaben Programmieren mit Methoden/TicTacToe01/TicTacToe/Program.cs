﻿using System;

namespace TicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            var leeresFeld = "#";
            var kreuz = "X";
            var kreis = "O";

            var spielFeld = new string[4, 4]
            {
                {" ","1", "2", "3"},
                { "A",leeresFeld, leeresFeld, leeresFeld},
                { "B",leeresFeld, leeresFeld, leeresFeld},
                { "C",leeresFeld, leeresFeld, leeresFeld}
            };

        }

    }
}
