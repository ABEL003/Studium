﻿using System;

namespace Musterlösung_5_6_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie einen Wochentag ein:");
            var wochentag = Console.ReadLine();

            var ausgabe = (wochentag == "Samstag" || wochentag == "Sonntag")
            ? "Hurra Wochenende!"
            : (
            wochentag == "Montag" ||
            wochentag == "Dienstag" ||
            wochentag == "Mittwoch" ||
            wochentag == "Donnerstag" ||
            wochentag == "Freitag"
            )
            ? "Oje, Sie müssen arbeiten!"
            : "Das ist kein Wochentag!";

            Console.WriteLine(ausgabe);
        }
    }
}