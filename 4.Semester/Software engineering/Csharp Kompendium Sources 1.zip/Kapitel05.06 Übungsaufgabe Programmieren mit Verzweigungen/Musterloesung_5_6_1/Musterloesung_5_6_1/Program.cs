﻿using System;

namespace Musterloesung_5_6_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie einen Wochentag ein:");
            var wochentag = Console.ReadLine();

            if (wochentag == "Samstag" || wochentag == "Sonntag")
            {
                Console.WriteLine("Hurra Wochenende!");
            }
            else
            {
                if (wochentag == "Montag" ||
                wochentag == "Dienstag" ||
                wochentag == "Mittwoch" ||
                wochentag == "Donnerstag" ||
                wochentag == "Freitag")
                {
                    Console.WriteLine("Oje, Sie müssen arbeiten!");
                }
                else
                {
                    Console.WriteLine("Das ist kein Wochentag!");
                }
            }
        }
    }
}
