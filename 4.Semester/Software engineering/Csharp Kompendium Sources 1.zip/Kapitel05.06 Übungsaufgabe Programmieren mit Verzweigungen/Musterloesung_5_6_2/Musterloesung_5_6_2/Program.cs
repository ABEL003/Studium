﻿using System;

namespace Musterloesung_5_6_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie einen Wochentag ein:");
            var wochentag = Console.ReadLine();

            switch (wochentag)
            {
                case "Samstag":
                case "Sonntag":
                    Console.WriteLine("Hurra Wochenende!");
                    break;
                case "Montag":
                case "Dienstag":
                case "Mittwoch":
                case "Donnerstag":
                case "Freitag":
                    Console.WriteLine("Oje, Sie müssen arbeiten!");
                    break;
                default:
                    Console.WriteLine("Das ist kein Wochentag!");
                    break;
            }
        }
    }
}
