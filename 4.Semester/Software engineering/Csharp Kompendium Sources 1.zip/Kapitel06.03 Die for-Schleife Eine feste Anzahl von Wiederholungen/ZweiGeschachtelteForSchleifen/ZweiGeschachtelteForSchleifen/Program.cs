﻿using System;

namespace ZweiGeschachtelteForSchleifen
{
    class Program
    {
        static void Main(string[] args)
        {
            var hoehe = 10;
            var breite = 10;
            var zeichen = "*";
            for (var i = 1; i <= hoehe; i++)
            {
                for (var j = 1; j <= breite; j++)
                {
                    Console.Write(zeichen);
                }
                Console.WriteLine();
            }
        }
    }
}
