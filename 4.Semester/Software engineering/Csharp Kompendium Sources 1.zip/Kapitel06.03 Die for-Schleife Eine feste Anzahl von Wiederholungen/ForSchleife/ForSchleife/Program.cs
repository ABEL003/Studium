﻿using System;

namespace ForSchleife
{
    class Program
    {
        static void Main(string[] args)
        {
            for (var i = 1; i <= 10; i++)
            {
                Console.WriteLine($"Ich zähle: {i}");
            }
        }
    }
}
