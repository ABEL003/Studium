﻿using System;

namespace Methoden
{
    class Program
    {
        static void Main(string[] args)
        {
            HalloEinzelperson("Robert");
            string[] vornamen = { "Katia", "Karl", "Thea" };
            HalloPersonenGruppe(vornamen);
        }

        static void HalloEinzelperson(string vorname)
        {
            Console.WriteLine($"Hallo {vorname}");
        }

        static void HalloPersonenGruppe(string[] vornamen)
        {
            foreach (var vorname in vornamen)
            {
                HalloEinzelperson(vorname);
            }
        }

    }
}