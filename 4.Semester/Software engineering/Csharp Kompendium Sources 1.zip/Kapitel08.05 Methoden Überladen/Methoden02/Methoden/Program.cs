﻿using System;

namespace Methoden
{
    class Program
    {
        static void Main(string[] args)
        {
            Hallo("Robert");
            string[] vornamen = { "Katia", "Karl", "Thea" };
            Hallo(vornamen);
        }

        static void Hallo(string vorname)
        {
            Console.WriteLine($"Hallo {vorname}");
        }

        static void Hallo(string[] vornamen)
        {
            foreach (var vorname in vornamen)
            {
                Hallo(vorname);
            }
        }

    }
}