﻿using System;

namespace WhileSchleife
{
    class Program
    {
        static void Main(string[] args)
        {
            int zaehler = 0;

            bool machWeiter = true;
            while (machWeiter)
            {
                zaehler = zaehler + 1;

                Console.WriteLine($"Ich zähle: {zaehler}");

                if (zaehler == 10)
                    machWeiter = false;
            }
        }
    }
}