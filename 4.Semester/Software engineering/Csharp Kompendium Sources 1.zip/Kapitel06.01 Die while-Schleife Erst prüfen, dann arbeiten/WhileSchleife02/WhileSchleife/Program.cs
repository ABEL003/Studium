﻿using System;

namespace WhileSchleife
{
    class Program

    {
        static void Main(string[] args)
        {
            int zaehler = 0;

            while (zaehler < 10)
            {
                zaehler++;
                Console.WriteLine($"Ich zähle: {zaehler}");
            }
        }
    }
}