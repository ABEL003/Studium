﻿/***********************************************
 * Hello World! in drei Sprachen
 * Englisch, Deutsch, Spanisch
 * *********************************************/

using System;

namespace Uebung_3_4
{
    /// <summary>
    /// Das Hauptprogramm
    /// </summary>
    class Program
    {
        /// <summary>
        /// Die Hauptmethode, der Startpunkt des Programms
        /// </summary>
        /// <param name="args">Die Anwendungsargumente, 
        /// werden hier nicht benutzt.</param>
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!"); //Englisch
            Console.WriteLine("Hallo Welt!"); //Deutsch
            Console.WriteLine("Hola Mundo!"); //Spanisch
        }
    }
}
