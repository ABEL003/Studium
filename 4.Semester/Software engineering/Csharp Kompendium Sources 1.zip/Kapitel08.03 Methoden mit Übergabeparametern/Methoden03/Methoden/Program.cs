﻿using System;

namespace Methoden
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Summe(1, 2, 3, 4, 5));
            Console.WriteLine(Summe(1, 2, 3));
        }

        static int Summe(params int[] summanden)
        {
            var summe = 0;
            foreach (var summand in summanden)
            {
                summe += summand;
            }
            return summe;
        }

    }
}