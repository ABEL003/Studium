﻿using System;

namespace Methoden
{
    class Program
    {
        static void Main(string[] args)
        {
            Hallo("Hello World!");
            Hallo("Hallo Welt!");
            Hallo("Hola Mundo!");
        }

        static void Hallo(string ausgabe)
        {
            Console.WriteLine(ausgabe);
        }
    }
}
