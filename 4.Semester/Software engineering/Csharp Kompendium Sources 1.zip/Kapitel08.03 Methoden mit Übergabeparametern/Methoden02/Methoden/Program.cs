﻿using System;

namespace Methoden
{
    class Program
    {
        static void Main(string[] args)
        {
            Hallo("Robert");
            Hallo("Katia", "Spanisch");
        }

        static void Hallo(string vorname, string
        sprache = "Deutsch")
        {
            switch (sprache)
            {
                case "Deutsch":
                    Console.WriteLine($"Hallo {vorname}!");
                    break;
                case "Englisch":
                    Console.WriteLine($"Hello {vorname}!");
                    break;
                case "Spanisch":
                    Console.WriteLine($"Hola {vorname}!");
                    break;
                default:
                    Console.WriteLine($"Die Sprache {sprache} spreche ich nicht!");
                    break;
            }
        }
    }
}
