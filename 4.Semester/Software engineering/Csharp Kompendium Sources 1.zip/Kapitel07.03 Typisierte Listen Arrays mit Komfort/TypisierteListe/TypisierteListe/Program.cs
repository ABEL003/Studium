﻿using System;
using System.Collections.Generic;

namespace TypisierteListe
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> wochentage = new List<string> { "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag" };
            foreach (var tag in wochentage)
            {
                Console.WriteLine(tag);
            }
        }
    }
}