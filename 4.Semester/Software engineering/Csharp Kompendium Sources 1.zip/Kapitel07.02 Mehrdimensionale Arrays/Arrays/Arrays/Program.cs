﻿using System;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {

            var spielfeld = new string[4, 4] {
                 { " ", "A", "B", "C" },
                 { "1", "#", "#", "#" },
                 { "2", "#", "#", "#" },
                 { "3", "#", "#", "#" }
             };

            for (var i = 0; i < 4; i++)
            {
                for (var j = 0; j < 4; j++)
                {
                    Console.Write(spielfeld[i, j]);
                }
                Console.WriteLine();
            }

        }
    }
}