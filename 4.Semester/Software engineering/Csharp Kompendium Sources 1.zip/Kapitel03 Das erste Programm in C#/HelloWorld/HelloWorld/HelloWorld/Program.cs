﻿/**************************************************
 * Das ist eine dynamische Variante des klassischen
 * Hello World-Programms, welches das erste 
 * Anwendungsargument am Bildschirm ausgibt.
 * Aufruf:
 * 
 * HelloWorld "Hallo Welt!"
 **************************************************/

using System;

namespace HelloWorld
{
    /// <summary>
    /// Das Hauptprogramm 
    /// </summary>
    class Program
    {
        /// <summary>
        /// Die Hauptmethode
        /// </summary>
        /// <param name="args">Die Anwendungsargumente: Nur das erste
        /// wird am Bildschirm ausgegeben.</param>
        static void Main(string[] args)
        {
            Console.WriteLine(args[0]);
        }
    }
}
