﻿using System;

namespace BedingteZuweisung
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie Ihren Benutzernamen ein:");
            var benutzer = Console.ReadLine();
            Console.WriteLine("Geben Sie Ihr Passwort ein:");
            var passwort = Console.ReadLine();

            var ausgabe = (benutzer == "Robert" && passwort == "1234")
            ? "Zugriff autorisiert."
            : "Zugriff verweigert.";

            Console.WriteLine(ausgabe);
        }
    }
}