﻿using System;

namespace BedingteZuweisung
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie Ihr Passwort ein:");
            var passwort = Console.ReadLine();

            var ausgabe = passwort == "1234" ? "Zugriff autorisiert." : "Zugriff verweigert.";

            Console.WriteLine(ausgabe);
        }
    }
}