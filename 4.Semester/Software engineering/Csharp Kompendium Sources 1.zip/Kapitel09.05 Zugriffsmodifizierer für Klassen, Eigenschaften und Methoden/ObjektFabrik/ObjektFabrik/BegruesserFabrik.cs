﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObjektFabrik
{
    public enum Sprache
    {
        Deutsch,
        Englisch,
        Spanisch
    }

    public class BegruesserFabrik
    {
        Sprache sprache;

        public BegruesserFabrik(Sprache sprache)
        {
            this.sprache = sprache;
        }

        public Begruesser ErzeugeBegruesser()
        {
            switch (sprache)
            {
                case Sprache.Englisch:
                    return new Begruesser("Hello World!");
                case Sprache.Deutsch:
                    return new Begruesser("Hallo Welt!");
                case Sprache.Spanisch:
                    return new Begruesser("Holla Mundo!");
                default:
                    return new Begruesser($"Ich kann kein { sprache }");
            }
        }
    }
}
