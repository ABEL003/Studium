﻿using System;

namespace ObjektFabrik
{
    class Program
    {
        static void Main(string[] args)
        {
            new BegruesserFabrik(Sprache.Englisch).ErzeugeBegruesser().Hallo();
        }
    }
}
