﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObjektFabrik
{
    public class Begruesser
    {
        string begruessung;

        public Begruesser(string begruessung)
        {
            this.begruessung = begruessung;
        }

        public void Hallo()
        {
            Console.WriteLine(begruessung);
        }
    }
}
