﻿using System;
using System.Collections.Generic;

namespace TelefonVerzeichnis
{
    class Program
    {
        static void Main(string[] args)
        {
            var telefonVerzeichnis = new Dictionary<string,(string FestNetz, string Mobilfunk, string Email)>
            {
                {"Robert", ("089 12345678", "0171 12345678", "robert@email.de") },
                {"Katia", ("089 244345636", "0171 4534564", "katia@email.de") },
                {"Karl", ("089 2434545636", "0171 4294564", "karl@email.de") },
                {"Thea", ("089 238545736", "0171 246732589","thea@email.de") }
            };

            var name = "";

            while (name != "Fertig!")
            {
                Console.WriteLine("Geben Sie bitte einen Namen ein: ");

                name = Console.ReadLine();
            }
        }
    }
}