﻿using System;

namespace DoWhileSchleife
{
    class Program
    {
        static void Main(string[] args)
        {
            var zaehler = 0;
            do
            {
                zaehler++;
                Console.WriteLine($"Ich zähle: {zaehler}");
            } while (zaehler < 10);
        }
    }
}