﻿using System;

namespace UnendlicheSchleife
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Die unendliche Geschichte...");

            while (1 == 1)
            {

            }
        }
    }
}