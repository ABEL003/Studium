﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonsolenApp
{
    class KonsolenApp
    {
        string begruessung = "Hallo Welt!";

        public KonsolenApp()
        {

        }

        public KonsolenApp(string begruessung)
        {
            this.begruessung = begruessung;
        }

        public void Start()
        {
            Console.WriteLine(begruessung);
        }
    }
}
