﻿using System;

namespace KonsolenApp
{
    class Program
    {
        static void Main(string[] args)
        {
            new KonsolenApp().Start();
            new KonsolenApp("Hello World!").Start();
        }
    }
}
