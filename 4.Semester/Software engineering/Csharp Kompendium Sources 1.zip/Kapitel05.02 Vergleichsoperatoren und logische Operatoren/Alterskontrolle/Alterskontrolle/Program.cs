﻿using System;

namespace Alterskontrolle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Wie alt sind Sie?");
            var alter = int.Parse(Console.ReadLine());
            if (alter >= 18)
                Console.WriteLine("Sie sind bereits volljährig!");
            else
                Console.WriteLine("Sie sind noch nicht volljährig!");
        }
    }
}