﻿using System;

namespace Methoden
{
    class Program
    {
        static void Main(string[] args)

        {
            Hallo();
        }

        static void Hallo()
        {
            Console.WriteLine("Hello World!");
        }
    }
}