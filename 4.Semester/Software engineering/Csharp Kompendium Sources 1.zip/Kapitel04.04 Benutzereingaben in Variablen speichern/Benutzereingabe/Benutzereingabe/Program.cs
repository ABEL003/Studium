﻿using System;

namespace Benutzereingabe
{
    class Program

    {
        static void Main(string[] args)
        {
            Console.WriteLine("Wie heißen Sie?");
            var benutzerName = Console.ReadLine();
            var ausgabe = $"Guten Tag {benutzerName}.";
            Console.WriteLine(ausgabe);
        }
    }
}