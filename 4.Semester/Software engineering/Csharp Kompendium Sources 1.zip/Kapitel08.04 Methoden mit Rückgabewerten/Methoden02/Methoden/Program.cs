﻿using System;

namespace Methoden
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geben Sie eine ganze Zahl:");

            var eingabe = Console.ReadLine();

            if (int.TryParse(eingabe, out int zahl))
            {
                Console.WriteLine($"Das doppelte von {zahl} ist {zahl * 2}.");
            }
            else
            {
                Console.WriteLine($"{eingabe} ist keine ganze Zahl.");
            }
        }

    }
}