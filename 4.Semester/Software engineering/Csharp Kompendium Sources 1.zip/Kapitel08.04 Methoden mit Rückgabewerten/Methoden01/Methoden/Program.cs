﻿using System;

namespace Methoden
{
    class Program
    {
        static void Main(string[] args)
        {
            var summe = SummeUndDifferenz(5, 2, out int differenz);
            Console.WriteLine($"Die Summe von 5 und 2 = {summe}");
            Console.WriteLine($"Die Differenz zwischen 5 und 2 = { differenz}");
        }

        static int SummeUndDifferenz(int a, int b, out int
        differenz)
        {
            differenz = a - b;
            return a + b;
        }

    }
}