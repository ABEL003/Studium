﻿using System;

namespace Methoden
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = 2;
            var b = 3;
            var c = VerdoppleUndAddiere(ref a, ref b);
            Console.WriteLine($"a = {a}");
            Console.WriteLine($"b = {b}");
            Console.WriteLine($"c = {c}");
        }

        static int VerdoppleUndAddiere(ref int a, ref int b)
        {
            a *= 2;
            b *= 2;
            return a + b;
        }

    }
}